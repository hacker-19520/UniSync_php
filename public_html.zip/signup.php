<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$pageTitle = 'Sign Up';

$universities = ['Emerson University Multan'];
$departments = ['Computing and Emerging Technologies','Business Administration','Engineering','Natural Sciences','Social Sciences','Humanities','Health Sciences','Law','Education'];
$shifts = ['Morning','Evening'];
$sections = ['A','B','C','D','E'];
$semesters = ['1','2','3','4','5','6','7','8'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up - UniSync</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body style="background:linear-gradient(135deg,#eff6ff,#e0e7ff);min-height:100vh;padding:32px 16px;">
<div style="max-width:760px;margin:0 auto;">
  <div style="text-align:center;margin-bottom:28px;">
    <a href="index.php" style="display:inline-flex;align-items:center;gap:8px;font-weight:800;font-size:1.4rem;background:linear-gradient(135deg,#2563eb,#4338ca);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">UniSync</a>
  </div>
  <div style="background:white;border-radius:20px;box-shadow:0 25px 50px -12px rgba(0,0,0,.15);padding:40px 36px;" class="animate-scale-in">
    <div style="text-align:center;margin-bottom:24px;">
      <div style="width:64px;height:64px;background:#dbeafe;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
        <svg style="width:32px;height:32px;color:#2563eb;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path stroke-linecap="round" stroke-linejoin="round" d="M22 21v-2a4 4 0 0 0-3-3.87"/><path stroke-linecap="round" stroke-linejoin="round" d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h1 style="font-size:1.6rem;font-weight:800;">Join UniSync</h1>
      <p style="color:#6b7280;font-size:.9rem;">Create your account to find your university duo</p>
    </div>

    <div class="alert alert-warning" style="font-size:.85rem;">
      ⚠️ <strong>Please use real information.</strong> Your account must be approved by an admin before you can login.
    </div>

    <div id="error-box" class="alert alert-error" style="display:none;"></div>
    <div id="success-box" class="alert alert-success" style="display:none;"></div>

    <form id="signup-form">
      <!-- PERSONAL INFO -->
      <div class="section-card blue">
        <h3><svg style="width:20px;height:20px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="#1e40af"><path stroke-linecap="round" stroke-linejoin="round" d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Personal Information</h3>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" class="input-field" placeholder="John Doe" required></div>
          <div class="form-group"><label class="form-label">Email Address *</label><input type="email" name="email" class="input-field" placeholder="john@university.edu" required></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Password *</label>
            <div style="position:relative;"><input type="password" name="password" id="password" class="input-field" placeholder="Min 6 characters" required>
              <button type="button" onclick="togglePwd()" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#9ca3af;" id="eye-btn">
                <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
          </div>
          <div class="form-group"><label class="form-label">Confirm Password *</label><input type="password" name="confirmPassword" id="confirmPassword" class="input-field" placeholder="Repeat password" required></div>
        </div>
        <!-- Image upload -->
        <div class="form-group">
          <label class="form-label">Profile Image * <span style="color:#dc2626;font-weight:700;">(Required)</span></label>
          <div class="upload-zone required" id="upload-zone" onclick="document.getElementById('img-input').click();">
            <div id="upload-content">
              <svg style="width:36px;height:36px;color:#fca5a5;margin:0 auto 8px;display:block;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 0 1 2.828 0L16 16m-2-2l1.586-1.586a2 2 0 0 1 2.828 0L20 14m-6-6h.01M6 20h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2z"/></svg>
              <p style="color:#dc2626;font-size:.85rem;font-weight:600;">⚠ Click to upload your profile picture (Required)</p>
            </div>
            <input type="file" id="img-input" accept="image/*" style="display:none;">
            <input type="hidden" name="image" id="image_data">
          </div>
        </div>
      </div>

      <!-- UNIVERSITY INFO -->
      <div class="section-card amber">
        <h3><svg style="width:20px;height:20px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="#92400e"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v5m-4 0h4"/></svg>University Information</h3>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">University *</label>
            <select name="university" class="input-field" required>
              <option value="">Select University</option>
              <?php foreach ($universities as $u): ?><option value="<?= htmlspecialchars($u) ?>"><?= htmlspecialchars($u) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Roll Number *</label><input type="text" name="rollNo" class="input-field" placeholder="e.g. 2021-CS-001" required></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">SAP ID</label><input type="text" name="sapId" class="input-field" placeholder="e.g. 12345"></div>
          <div class="form-group"><label class="form-label">Department *</label>
            <select name="department" id="dept" class="input-field" required>
              <option value="">Select Department</option>
              <?php foreach ($departments as $d): ?><option value="<?= htmlspecialchars($d) ?>"><?= htmlspecialchars($d) ?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Course *</label>
            <select name="course" id="course" class="input-field" disabled required><option value="">Select Department First</option></select>
          </div>
          <div class="form-group"><label class="form-label">Shift *</label>
            <select name="shift" class="input-field" required>
              <option value="">Select Shift</option>
              <?php foreach ($shifts as $s): ?><option value="<?= $s ?>"><?= $s ?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Section *</label>
            <select name="section" class="input-field" required>
              <option value="">Select Section</option>
              <?php foreach ($sections as $s): ?><option value="<?= $s ?>"><?= $s ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Semester *</label>
            <select name="semester" class="input-field" required>
              <option value="">Select Semester</option>
              <?php foreach ($semesters as $s): ?><option value="<?= $s ?>">Semester <?= $s ?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>

      <!-- ADDITIONAL INFO -->
      <div class="section-card purple">
        <h3><svg style="width:20px;height:20px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="#6b21a8"><path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 1 1 7.072 0l-.548.547A3.374 3.374 0 0 0 14 18.469V19a2 2 0 1 1-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>Additional Information</h3>
        <div class="form-group"><label class="form-label">Verification Method *</label>
          <select name="verificationMethod" class="input-field" required>
            <option value="email">Email OTP (recommended)</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Reason to Join *</label>
          <select name="reason" class="input-field" required>
            <option value="study duo">Find a Study Duo</option>
            <option value="friends">Make Friends</option>
            <option value="others">Others</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Your Qualities &amp; Niche</label>
          <textarea name="qualities" rows="3" class="input-field" placeholder="Describe your qualities, skills, interests..."></textarea>
        </div>
      </div>

      <button type="submit" id="submit-btn" class="btn btn-primary btn-block" style="padding:14px;font-size:1rem;">
        <svg style="width:20px;height:20px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM3 20a6 6 0 0 1 12 0v1H3v-1z"/></svg>
        Create Account
      </button>
    </form>
    <p style="text-align:center;margin-top:16px;color:#6b7280;font-size:.9rem;">
      Already have an account? <a href="login.php" style="color:#2563eb;font-weight:600;">Login here</a>
    </p>
    <p style="text-align:center;margin-top:8px;color:#6b7280;font-size:.9rem;">
      <a href="index.php" style="color:#4b5563;font-weight:600;">← Back to Home</a>
    </p>
  </div>
</div>
<script src="assets/app.js"></script>
<script>
setupImagePreview('img-input','upload-zone');
setupDeptCourse('dept','course');

function togglePwd() {
  const p=document.getElementById('password'), cp=document.getElementById('confirmPassword');
  const show=p.type==='password'; p.type=cp.type=show?'text':'password';
}

document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  document.getElementById('error-box').style.display='none';
  const data = {};
  for (let el of e.target.elements) {
    if (el.name && el.type !== 'file') {
      data[el.name] = el.value;
    }
  }
  const imageInput = document.getElementById('image_data');
  if (imageInput && imageInput.value) {
    data.image = imageInput.value;
  }
  if (!data.image) { document.getElementById('error-box').textContent='Profile image is required.'; document.getElementById('error-box').style.display='flex'; return; }
  if (data.password !== data.confirmPassword) { document.getElementById('error-box').textContent='Passwords do not match.'; document.getElementById('error-box').style.display='flex'; return; }
  if (data.password.length < 6) { document.getElementById('error-box').textContent='Password must be at least 6 characters.'; document.getElementById('error-box').style.display='flex'; return; }
  const btn=document.getElementById('submit-btn'); btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Creating Account...';
  const {ok,res_data} = await fetch('api/auth/register.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})
    .then(async r=>({ok:r.ok,res_data:await r.json()}));
  btn.disabled=false; btn.textContent='Create Account';
  if (!ok) { document.getElementById('error-box').textContent=res_data.error||'Registration failed'; document.getElementById('error-box').style.display='flex'; return; }
  // Send OTP once, then redirect with debug OTP when available.
  const otpRes = await fetch('api/auth/send-otp.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      email:data.email,
      name:data.name,
      method:data.verificationMethod || 'email'
    })
  }).then(async r => ({ ok: r.ok, data: await r.json().catch(() => ({})) }));

  if (!otpRes.ok) {
    document.getElementById('error-box').textContent = otpRes.data.error || 'Account created, but OTP could not be sent. Please resend on verify page.';
    document.getElementById('error-box').style.display='flex';
  }

  const query = new URLSearchParams({
    email: data.email,
    name: data.name,
    method: data.verificationMethod || 'email'
  });
  if (otpRes.data?.mockOtp) query.set('otp', otpRes.data.mockOtp);
  window.location.href='verify-email.php?'+query.toString();
});
</script>
</body>
</html>
