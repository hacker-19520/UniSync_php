<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle = 'Matches';
$activePage = 'matches';
$defaultTab = htmlspecialchars($_GET['tab'] ?? 'find');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Matches - UniSync</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main-content animate-fade-in">
    <div class="topbar"><h2>Matches &amp; Requests</h2></div>

    <div class="tabs" id="tabs">
      <button class="tab-btn <?= $defaultTab==='find'?'active':'' ?>" data-tab="find">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> Find Matches
      </button>
      <button class="tab-btn <?= $defaultTab==='sent'?'active':'' ?>" data-tab="sent">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> My Requests
      </button>
      <button class="tab-btn <?= $defaultTab==='received'?'active':'' ?>" data-tab="received">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg> Requests For Me
      </button>
      <button class="tab-btn <?= $defaultTab==='matches'?'active':'' ?>" data-tab="matches">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg> My Matches
      </button>
    </div>

    <div id="tab-content">
      <div style="text-align:center;padding:60px;"><div class="spinner spinner-dark" style="width:36px;height:36px;border-width:3px;margin:0 auto;"></div></div>
    </div>

    <div id="profile-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1200;align-items:center;justify-content:center;">
      <div style="background:#fff;border-radius:18px;max-width:580px;width:95%;max-height:90vh;overflow-y:auto;box-shadow:0 24px 50px -12px rgba(0,0,0,.25);">
        <div style="padding:20px 24px;border-bottom:1px solid #f3f4f6;display:flex;align-items:center;justify-content:space-between;">
          <h3 style="font-weight:800;font-size:1.2rem;">Full Profile</h3>
          <button type="button" onclick="closeProfileModal()" class="btn btn-ghost btn-sm">Close</button>
        </div>
        <div id="profile-modal-content" style="padding:24px;"></div>
      </div>
    </div>
  </main>
</div>
<script src="assets/app.js"></script>
<script>
const reasonLabels = {'study duo':'Study Duo','friends':'Friends','others':'Others'};
const tabCache = {
  find: null,
  sent: null,
  received: null,
  matches: null
};

async function loadTab(tab) {
  const content = document.getElementById('tab-content');
  content.innerHTML = '<div style="text-align:center;padding:60px;"><div class="spinner spinner-dark" style="width:36px;height:36px;border-width:3px;margin:0 auto;"></div></div>';

  if (tab === 'find') {
    if (tabCache.find) {
      renderFindTab(content, tabCache.find);
      return;
    }
    const {ok,data} = await api('api/profile/users.php');
    const users = data?.users ?? [];
    tabCache.find = users;
    renderFindTab(content, users);
  } else if (tab === 'sent') {
    if (tabCache.sent) {
      renderSentTab(content, tabCache.sent);
      return;
    }
    const {data} = await api('api/match/my-requests.php');
    const reqs = data?.requests ?? [];
    tabCache.sent = reqs;
    renderSentTab(content, reqs);
  } else if (tab === 'received') {
    // Make this tab feel instant after first fetch.
    if (tabCache.received) {
      renderReceivedTab(content, tabCache.received);
      return;
    }
    const {data} = await api('api/match/requests-for-me.php');
    const reqs = data?.requests ?? [];
    tabCache.received = reqs;
    renderReceivedTab(content, reqs);
  } else if (tab === 'matches') {
    if (tabCache.matches) {
      renderMatchesTab(content, tabCache.matches);
      return;
    }
    const {data} = await api('api/match/my-matches.php');
    const matches = data?.matches ?? [];
    tabCache.matches = matches;
    renderMatchesTab(content, matches);
  }
}

function renderFindTab(content, users) {
  if (!users.length) { content.innerHTML = `<div class="empty-state"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg><p>No students found.</p></div>`; return; }
  content.innerHTML = `<div style="margin-bottom:16px;position:relative;">
      <svg style="position:absolute;left:12px;top:50%;transform:translateY(-50%);width:18px;height:18px;color:#9ca3af;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input id="search" type="text" class="input-field" style="padding-left:40px;" placeholder="Search by name, university, department...">
    </div>
    <div class="card-grid card-grid-3" id="users-grid">${users.map(u => userCard(u)).join('')}</div>`;
    document.getElementById('search').addEventListener('input', function() {
      const q = this.value.toLowerCase();
      document.querySelectorAll('.u-card').forEach(c => {
        const txt = c.dataset.search.toLowerCase();
        c.style.display = txt.includes(q) ? '' : 'none';
      });
    });
}

function renderSentTab(content, reqs) {
  if (!reqs.length) { content.innerHTML = `<div class="empty-state"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg><p>No requests sent yet.</p></div>`; return; }
  content.innerHTML = reqs.map(r => `
      <div class="card" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
        <div style="display:flex;align-items:center;gap:12px;">
          <img src="${escHtml(r.image||'https://via.placeholder.com/40')}" class="avatar-sm" onerror="this.src='https://via.placeholder.com/40'">
          <div><p style="font-weight:600;">${escHtml(r.name)}</p><p style="font-size:.82rem;color:#6b7280;">${escHtml(r.university)}</p></div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <button type="button" onclick="viewProfileFromEncoded('${encodeUser(r)}')" class="btn btn-ghost btn-sm">View Profile</button>
          <span class="badge badge-${r.status}">${r.status.charAt(0).toUpperCase()+r.status.slice(1)}</span>
        </div>
      </div>`).join('');
}

function renderReceivedTab(content, reqs) {
  if (!reqs.length) { content.innerHTML = `<div class="empty-state"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><p>No pending requests.</p></div>`; return; }
  content.innerHTML = reqs.map(r => `
      <div class="card" style="margin-bottom:12px;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
          <img src="${escHtml(r.image||'https://via.placeholder.com/40')}" class="avatar-sm" onerror="this.src='https://via.placeholder.com/40'">
          <div><p style="font-weight:600;">${escHtml(r.name)}</p><p style="font-size:.82rem;color:#6b7280;">${escHtml(r.university)} • ${escHtml(r.department)}</p></div>
        </div>
        <div style="display:flex;gap:10px;">
          <button type="button" onclick="viewProfileFromEncoded('${encodeUser(r)}')" class="btn btn-ghost" style="flex:1;">View Profile</button>
          <button onclick="handleReq(${r.id},'accept',this)" class="btn btn-success" style="flex:1;">
            <svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg> Accept
          </button>
          <button onclick="handleReq(${r.id},'reject',this)" class="btn btn-danger" style="flex:1;">
            <svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Reject
          </button>
        </div>
      </div>`).join('');
}

function renderMatchesTab(content, matches) {
  if (!matches.length) { content.innerHTML = `<div class="empty-state"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg><p>No matches yet. Send requests to connect!</p></div>`; return; }
  content.innerHTML = matches.map(m => `
      <div class="card match-card" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
        <div style="display:flex;align-items:center;gap:12px;">
          <img src="${escHtml(m.matchImage||'https://via.placeholder.com/40')}" class="avatar-sm match-image" onerror="this.src='https://via.placeholder.com/40'">
          <div><p style="font-weight:600;">${escHtml(m.matchName)}</p><p style="font-size:.82rem;color:#6b7280;">${escHtml(m.matchUniversity)} • ${escHtml(m.matchDepartment)} • ${escHtml(m.matchCourse)}</p><p style="font-size:.78rem;color:#9ca3af;">${escHtml(m.matchShift||'')} Shift • Sec ${escHtml(m.matchSection||'')} • Sem ${escHtml(m.matchSemester||'')}</p></div>
        </div>
        <div style="display:flex;gap:8px;">
          <button type="button" onclick="viewProfileFromEncoded('${encodeUser({
            name: m.matchName,
            image: m.matchImage,
            university: m.matchUniversity,
            department: m.matchDepartment,
            course: m.matchCourse,
            shift: m.matchShift,
            section: m.matchSection,
            semester: m.matchSemester
          })}')" class="btn btn-ghost btn-sm">View Profile</button>
          <a href="chat.php?id=${m.id}" class="btn btn-primary btn-sm"><svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg> Chat</a>
        </div>
      </div>`).join('');
}

function userCard(u) {
  return `<div class="match-card u-card" data-search="${escHtml(u.name)} ${escHtml(u.university)} ${escHtml(u.department)}">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
      <img src="${escHtml(u.image||'https://via.placeholder.com/48')}" class="avatar-md match-image" onerror="this.src='https://via.placeholder.com/48'">
      <div><h3 style="font-weight:700;">${escHtml(u.name)}</h3><p style="font-size:.82rem;color:#6b7280;">${escHtml(u.university)}</p></div>
    </div>
    <div style="font-size:.85rem;color:#4b5563;margin-bottom:10px;line-height:1.7;">
      <p><strong>Dept:</strong> ${escHtml(u.department)}</p>
      <p><strong>Course:</strong> ${escHtml(u.course)}</p>
      <p><strong>Shift:</strong> ${escHtml(u.shift||'N/A')} • <strong>Sec:</strong> ${escHtml(u.section||'N/A')} • <strong>Sem:</strong> ${escHtml(u.semester||'N/A')}</p>
      <p><strong>Looking for:</strong> ${escHtml(reasonLabels[u.reason]||u.reason)}</p>
      ${u.qualities?`<p><strong>Qualities:</strong> ${escHtml(u.qualities)}</p>`:''}
    </div>
    <div style="display:flex;gap:8px;">
      <button type="button" onclick="viewProfileFromEncoded('${encodeUser(u)}')" class="btn btn-ghost btn-block">View Profile</button>
      <button onclick="sendReq(${u.id},this)" class="btn btn-primary btn-block">
      <svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Send Request
      </button>
    </div>
  </div>`;
}

async function sendReq(userId, btn) {
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Sending...';
  const {ok,data} = await api('api/match/request.php','POST',{receiverId:userId});
  if (ok) { btn.closest('.u-card').style.opacity='.4'; btn.textContent='✓ Request Sent'; showToast('Request sent!'); }
  else { btn.disabled=false; btn.textContent='Send Request'; showToast(data.error||'Failed','error'); }
}

async function handleReq(id, action, btn) {
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span>';
  const url = action==='accept' ? `api/match/accept.php?id=${id}` : `api/match/reject.php?id=${id}`;
  const {ok,data} = await api(url,'POST');
  if (ok) {
    // Refresh cache after request status changes.
    tabCache.received = null;
    tabCache.sent = null;
    tabCache.matches = null;
    showToast(action==='accept'?'Request accepted!':'Request rejected.');
    loadTab('received');
  }
  else { btn.disabled=false; btn.textContent=action==='accept'?'Accept':'Reject'; showToast(data.error||'Failed','error'); }
}

setupTabs('tabs','tab-content',loadTab);
loadTab('<?= $defaultTab ?>');
// Prefetch "Requests For Me" in background for faster tab open.
api('api/match/requests-for-me.php').then(({ data }) => {
  tabCache.received = data?.requests ?? [];
}).catch(() => {});

function closeProfileModal() {
  document.getElementById('profile-modal').style.display = 'none';
}

function encodeUser(user) {
  return encodeURIComponent(JSON.stringify(user || {}));
}

function viewProfileFromEncoded(encoded) {
  try {
    const user = JSON.parse(decodeURIComponent(encoded || ''));
    openProfileModal(user);
  } catch (e) {
    showToast('Could not open profile', 'error');
  }
}

function openProfileModal(user) {
  if (!user) return;
  const modal = document.getElementById('profile-modal');
  const body = document.getElementById('profile-modal-content');
  body.innerHTML = `
    <div style="text-align:center;margin-bottom:20px;">
      <img src="${escHtml(user.image || 'https://via.placeholder.com/120')}" style="width:110px;height:110px;border-radius:16px;object-fit:cover;border:3px solid #dbeafe;" onerror="this.src='https://via.placeholder.com/120'">
      <h4 style="font-size:1.35rem;font-weight:800;margin-top:10px;">${escHtml(user.name || 'User')}</h4>
      <span class="vip-chip">Verified Preview</span>
    </div>
    <div style="display:grid;gap:8px;font-size:.95rem;">
      <div><strong>University:</strong> ${escHtml(user.university || 'N/A')}</div>
      <div><strong>Department:</strong> ${escHtml(user.department || 'N/A')}</div>
      <div><strong>Course:</strong> ${escHtml(user.course || 'N/A')}</div>
      <div><strong>Shift / Section / Semester:</strong> ${escHtml(user.shift || 'N/A')} / ${escHtml(user.section || 'N/A')} / ${escHtml(user.semester || 'N/A')}</div>
      <div><strong>Looking For:</strong> ${escHtml(reasonLabels[user.reason] || user.reason || 'N/A')}</div>
      <div><strong>Qualities:</strong> ${escHtml(user.qualities || 'N/A')}</div>
    </div>
  `;
  modal.style.display = 'flex';
}
</script>
</body>
</html>
