<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$userId = (int)$_SESSION['user_id'];
$stmt=$conn->prepare("SELECT * FROM users WHERE id=?"); $stmt->bind_param("i",$userId); $stmt->execute();
$profile=$stmt->get_result()->fetch_assoc(); $stmt->close();
$pageTitle = 'My Profile';
$activePage = 'profile';
$departments = ['Computing and Emerging Technologies','Business Administration','Engineering','Natural Sciences','Social Sciences','Humanities','Health Sciences','Law','Education'];
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>My Profile - UniSync</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main-content animate-fade-in">
    <div class="topbar"><h2>My Profile</h2></div>

    <div style="max-width:680px;margin:0 auto;">
      <div class="card vip-surface animate-scale-in">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
          <div>
            <span class="vip-chip">Profile Preview</span>
            <h3 class="vip-title" style="font-weight:800;font-size:1.2rem;margin-top:6px;">Profile Information</h3>
          </div>
          <button id="edit-btn" onclick="toggleEdit()" class="btn btn-ghost btn-sm">
            <svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-5m-1.414-9.414a2 2 0 1 1 2.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
            Edit
          </button>
        </div>

        <div id="msg-box" style="display:none;margin-bottom:16px;"></div>

        <!-- Avatar -->
        <div style="text-align:center;margin-bottom:28px;">
          <div style="position:relative;display:inline-block;">
            <img id="avatar-img" src="<?= htmlspecialchars($profile['image'] ?? '') ?>" class="avatar-lg" onerror="this.src='https://via.placeholder.com/96'">
            <button id="cam-btn" style="display:none;position:absolute;bottom:0;right:0;background:#2563eb;color:white;border:none;border-radius:50%;width:32px;height:32px;cursor:pointer;align-items:center;justify-content:center;" onclick="document.getElementById('img-input').click()">
              <svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
            </button>
            <input type="file" id="img-input" accept="image/*" style="display:none;" onchange="previewImg(this)">
            <input type="hidden" id="new_image">
          </div>
          <p style="margin-top:10px;font-weight:700;font-size:1.1rem;"><?= htmlspecialchars($profile['name']) ?></p>
          <p style="color:#6b7280;font-size:.85rem;"><?= htmlspecialchars($profile['email']) ?></p>
          <?php if ($profile['isAdmin']): ?><span class="badge badge-admin" style="margin-top:4px;">Admin</span><?php endif; ?>
        </div>

        <form id="profile-form" onsubmit="saveProfile(event)">
          <div class="grid-2" style="margin-bottom:16px;">
            <?php
            $fields = [
              ['Full Name','name','text',$profile['name']??''],
              ['Email','email','email',$profile['email']??''],
              ['Roll Number','rollNo','text',$profile['rollNo']??''],
              ['SAP ID','sapId','text',$profile['sapId']??''],
              ['University','university','text',$profile['university']??''],
              ['Department','department','select',$profile['department']??''],
              ['Course / Program','course','text',$profile['course']??''],
              ['Shift','shift','text',$profile['shift']??''],
              ['Section','section','text',$profile['section']??''],
              ['Semester','semester','text',$profile['semester']??''],
            ];
            foreach ($fields as [$label,$name,$type,$val]):
            ?>
            <div class="form-group">
              <label class="form-label"><?= $label ?></label>
              <?php if ($name==='email'): ?>
                <div class="profile-field"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 0 0 2.22 0L21 8M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"/></svg><?= htmlspecialchars($val ?: 'N/A') ?></div>
                <input type="hidden" name="email" value="<?= htmlspecialchars($val) ?>">
              <?php elseif ($type==='select'): ?>
                <select name="<?= $name ?>" class="input-field field-input" disabled style="color:inherit;">
                  <?php foreach ($departments as $d): ?><option value="<?= htmlspecialchars($d) ?>" <?= $val===$d?'selected':'' ?>><?= htmlspecialchars($d) ?></option><?php endforeach; ?>
                </select>
              <?php else: ?>
                <input type="<?= $type ?>" name="<?= $name ?>" class="input-field field-input" value="<?= htmlspecialchars($val) ?>" disabled style="background:transparent;border-color:transparent;">
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>

          <div class="form-group">
            <label class="form-label">Reason to Join</label>
            <select name="reason" class="input-field field-input" disabled>
              <?php foreach (['study duo'=>'Find a Study Duo','friends'=>'Make Friends','others'=>'Others'] as $v=>$l): ?>
                <option value="<?= $v ?>" <?= ($profile['reason']??'')===$v?'selected':'' ?>><?= $l ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Qualities &amp; Niche</label>
            <textarea name="qualities" rows="3" class="input-field field-input" disabled style="background:transparent;border-color:transparent;"><?= htmlspecialchars($profile['qualities'] ?? '') ?></textarea>
          </div>

          <button type="submit" id="save-btn" class="btn btn-primary btn-block" style="display:none;padding:12px;">
            <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>
            Save Changes
          </button>
        </form>
      </div>
    </div>
  </main>
</div>
<script src="/assets/app.js"></script>
<script>
let editMode = false;

function toggleEdit() {
  editMode = !editMode;
  document.querySelectorAll('.field-input').forEach(el => {
    el.disabled = !editMode;
    if (editMode) { el.style.background=''; el.style.borderColor=''; }
    else { el.style.background='transparent'; el.style.borderColor='transparent'; }
  });
  document.getElementById('save-btn').style.display = editMode ? 'flex' : 'none';
  document.getElementById('cam-btn').style.display = editMode ? 'flex' : 'none';
  document.getElementById('edit-btn').innerHTML = editMode
    ? `<svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Cancel`
    : `<svg style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-5m-1.414-9.414a2 2 0 1 1 2.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg> Edit`;
}

function previewImg(input) {
  const file = input.files[0]; if (!file) return;
  if (file.size > 5*1024*1024) { showToast('Image must be under 5MB','error'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('avatar-img').src = e.target.result;
    document.getElementById('new_image').value = e.target.result;
  };
  reader.readAsDataURL(file);
}

async function saveProfile(e) {
  e.preventDefault();
  const btn = document.getElementById('save-btn'); btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Saving...';
  const fd = new FormData(e.target);
  const data = Object.fromEntries(fd.entries());
  const newImg = document.getElementById('new_image').value;
  if (newImg) data.image = newImg;
  const {ok,data:res} = await api('/api/profile/me.php','PUT',data);
  btn.disabled=false; btn.innerHTML='Save Changes';
  const msgBox = document.getElementById('msg-box');
  if (ok) {
    msgBox.className='alert alert-success'; msgBox.textContent='Profile updated successfully!'; msgBox.style.display='flex';
    toggleEdit(); setTimeout(()=>msgBox.style.display='none',3000);
  } else {
    msgBox.className='alert alert-error'; msgBox.textContent=res.error||'Update failed'; msgBox.style.display='flex';
  }
}
</script>
</body>
</html>
