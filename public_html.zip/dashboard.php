<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$pageTitle = 'Dashboard';
$activePage = 'dashboard';
$u = get_session_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - UniSync</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main-content animate-fade-in">
    <div class="topbar animate-slide-up">
      <div>
        <span class="vip-chip">VIP Dashboard</span>
        <h2 class="vip-title">Welcome back, <?= htmlspecialchars($u['name']) ?>! 👋</h2>
        <p style="color:#6b7280;font-size:.9rem;">Here's what's happening in your UniSync network.</p>
      </div>
    </div>

    <!-- Stats will be loaded by JS -->
    <div class="card-grid card-grid-3" style="margin-bottom:24px;" id="stats-grid">
      <?php foreach ([['blue','My Matches','matches','M4.318 6.318a4.5 4.5 0 0 0 0 6.364L12 20.364l7.682-7.682a4.5 4.5 0 0 0-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 0 0-6.364 0z'],['green','Requests Sent','sent','M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 8 0 4 4 0 0 0-8 0M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75'],['purple','Requests Received','received','M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z']] as [$c,$l,$k,$ico]): ?>
      <div class="card stat-card vip-surface" style="background:var(--<?= $c ?>-50);border:1px solid var(--<?= $c ?>-100);">
        <div><p class="stat-label" style="color:var(--<?= $c ?>-600);"><?= $l ?></p><p class="stat-value" style="color:var(--<?= $c ?>-900);" id="stat-<?= $k ?>">—</p></div>
        <div class="stat-icon" style="background:var(--<?= $c ?>-100);"><svg style="color:var(--<?= $c ?>-600);" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="<?= $ico ?>"/></svg></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Quick Actions -->
    <div class="card vip-surface" style="margin-bottom:24px;">
      <h3 style="font-weight:700;margin-bottom:16px;">Quick Actions</h3>
      <div class="card-grid card-grid-2">
        <a href="matches.php" style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:#f9fafb;border-radius:10px;transition:all .25s ease;" onmouseover="this.style.background='#eff6ff'" onmouseout="this.style.background='#f9fafb'">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="background:#dbeafe;padding:10px;border-radius:10px;"><svg style="width:20px;height:20px;color:#2563eb;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
            <div><p style="font-weight:600;">Find Matches</p><p style="font-size:.82rem;color:#6b7280;">Discover students like you</p></div>
          </div>
          <svg style="width:18px;height:18px;color:#9ca3af;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/></svg>
        </a>
        <a href="profile.php" style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:#f9fafb;border-radius:10px;transition:all .25s ease;" onmouseover="this.style.background='#f0fdf4'" onmouseout="this.style.background='#f9fafb'">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="background:#dcfce7;padding:10px;border-radius:10px;"><svg style="width:20px;height:20px;color:#16a34a;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
            <div><p style="font-weight:600;">Update Profile</p><p style="font-size:.82rem;color:#6b7280;">Improve your chances</p></div>
          </div>
          <svg style="width:18px;height:18px;color:#9ca3af;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/></svg>
        </a>
      </div>
    </div>

    <!-- Recent Matches -->
    <div class="card vip-surface">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
        <h3 style="font-weight:700;">Recent Matches</h3>
        <a href="matches.php?tab=matches" style="font-size:.85rem;color:#2563eb;font-weight:600;">View all</a>
      </div>
      <div id="recent-matches">
        <div class="empty-state"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg><p>No matches yet. Start by finding students!</p></div>
      </div>
    </div>
    <div class="card vip-surface" style="margin-top:24px;">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;">
        <h3 style="font-weight:700;">Daily Pro Tip</h3>
        <span class="vip-chip" id="tip-badge">Growth Mode</span>
      </div>
      <p id="daily-tip" style="margin-top:10px;color:#4b5563;font-size:.92rem;">Complete your profile details for better quality matches.</p>
    </div>
  </main>
</div>
<script src="assets/app.js"></script>
<script>
(async () => {
  const [matchRes, sentRes, recvRes] = await Promise.all([
    api('api/match/my-matches.php'),
    api('api/match/my-requests.php'),
    api('api/match/requests-for-me.php'),
  ]);
  document.getElementById('stat-matches').textContent = matchRes.data?.matches?.length ?? 0;
  document.getElementById('stat-sent').textContent = sentRes.data?.requests?.length ?? 0;
  document.getElementById('stat-received').textContent = recvRes.data?.requests?.length ?? 0;

  const matches = matchRes.data?.matches?.slice(0,3) ?? [];
  if (matches.length > 0) {
    document.getElementById('recent-matches').innerHTML = matches.map(m => `
      <a href="chat.php?id=${m.id}" style="display:flex;align-items:center;gap:14px;padding:12px;background:#f9fafb;border-radius:10px;margin-bottom:8px;transition:all .2s ease;" onmouseover="this.style.background='#eff6ff'" onmouseout="this.style.background='#f9fafb'">
        <img src="${escHtml(m.matchImage||'https://via.placeholder.com/40')}" class="avatar-sm" onerror="this.src='https://via.placeholder.com/40'">
        <div style="flex:1;"><p style="font-weight:600;">${escHtml(m.matchName)}</p><p style="font-size:.82rem;color:#6b7280;">${escHtml(m.matchUniversity)}</p></div>
        <svg style="width:18px;height:18px;color:#2563eb;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
      </a>`).join('');
  }

  const tips = [
    'Complete your profile details for better quality matches.',
    'Send thoughtful connection requests to improve acceptance rate.',
    'Keep your profile image clear and professional for trust.',
    'Respond quickly to requests to stay active in your network.'
  ];
  const idx = (new Date().getDate() - 1) % tips.length;
  const tipEl = document.getElementById('daily-tip');
  if (tipEl) tipEl.textContent = tips[idx];
})();
</script>
</body></html>
