-- UniSync PHP Database Schema (MySQL)
-- Run: mysql -u root -p unisync_db < unisync_db.sql
-- Or phpMyAdmin: CREATE DATABASE unisync_db; then import.

-- Ensure you have created the database from your hosting panel (e.g., Hostinger hPanel) before importing.
-- Do NOT use CREATE DATABASE or USE statements here as shared hosting restricts these permissions.

-- Users table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `rollNo` VARCHAR(100) UNIQUE,
  `sapId` VARCHAR(100) UNIQUE,
  `university` VARCHAR(255) NOT NULL,
  `department` VARCHAR(255) NOT NULL,
  `course` VARCHAR(255) NOT NULL,
  `shift` VARCHAR(50),
  `section` VARCHAR(10),
  `semester` VARCHAR(20),
  `image` TEXT NOT NULL,
  `reason` TEXT NOT NULL,
  `qualities` TEXT,
  `isVerified` TINYINT(1) DEFAULT 0,
  `isAdmin` TINYINT(1) DEFAULT 0,
  `approvalStatus` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `rejectionReason` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- OTP codes
CREATE TABLE IF NOT EXISTS `otp_codes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL,
  `code` VARCHAR(6) NOT NULL,
  `expiresAt` DATETIME NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Connection requests
CREATE TABLE IF NOT EXISTS `requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `senderId` INT NOT NULL,
  `receiverId` INT NOT NULL,
  `status` ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiverId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_request` (`senderId`, `receiverId`)
) ENGINE=InnoDB;

-- Messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `requestId` INT NOT NULL,
  `senderId` INT NOT NULL,
  `content` TEXT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`requestId`) REFERENCES `requests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Insert demo admin (change password!)
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `university`, `department`, `course`, `image`, `reason`, `isVerified`, `isAdmin`, `approvalStatus`) VALUES 
('Admin User', 'admin@unisync.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emerson University', 'Software Engineering', 'BS SE', 'assets/default-avatar.jpg', 'Demo admin account', 1, 1, 'approved');

-- Insert Ahmad Bilal admin
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `university`, `department`, `course`, `image`, `reason`, `isVerified`, `isAdmin`, `approvalStatus`) VALUES 
('Ahmad Bilal', 'ahmadbilal9436@gmail.com', '$2y$10$JmNoihvf5UzFY7p36w.6.e21KCLLsZla4RpPsuJ8MYvZJCtfCKxyS', 'Emerson University', 'Software Engineering', 'BS SE', 'assets/default-avatar.jpg', 'Admin account', 1, 1, 'approved');

-- Note: Demo password is 'password'. Hash: password_hash('password', PASSWORD_DEFAULT)
