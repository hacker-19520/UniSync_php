<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();
$pageTitle = 'Admin Panel';
$activePage = 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - UniSync</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main-content animate-fade-in">
    <div class="topbar">
      <div>
        <h2>Admin Panel</h2>
        <p style="color:#6b7280;font-size:.88rem;">Manage users, requests, and messages</p>
      </div>
    </div>

    <!-- Stats -->
    <div class="card-grid" style="grid-template-columns:repeat(5,1fr);gap:16px;margin-bottom:24px;" id="stats-grid">
      <?php
      $statDefs = [
        ['blue','Total Users','totalUsers'],
        ['green','Verified','verifiedUsers'],
        ['amber','Pending','pendingApprovals'],
        ['purple','Requests','totalRequests'],
        ['rose','Messages','totalMessages'],
      ];
      foreach ($statDefs as [$c,$l,$k]): ?>
      <div class="card stat-card" style="background:var(--<?= $c ?>-50,#fff);border:1px solid var(--<?= $c ?>-100,#e5e7eb);padding:18px;">
        <div><p style="font-size:.78rem;font-weight:600;color:var(--<?= $c ?>-600,#2563eb);"><?= $l ?></p><p style="font-size:1.8rem;font-weight:800;" id="stat-<?= $k ?>">—</p></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Section Tabs -->
    <div class="tabs" id="admin-tabs">
      <button class="tab-btn active" data-tab="users">Users</button>
      <button class="tab-btn" data-tab="requests">Requests</button>
      <button class="tab-btn" data-tab="messages">Messages</button>
    </div>

    <!-- Modal for reject reason -->
    <div id="reject-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;">
      <div style="background:white;border-radius:16px;padding:32px;max-width:440px;width:90%;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);">
        <h3 style="font-weight:700;margin-bottom:12px;">Reject User</h3>
        <p style="color:#6b7280;font-size:.9rem;margin-bottom:16px;">Please provide a reason for rejection:</p>
        <textarea id="reject-reason" class="input-field" rows="3" placeholder="e.g. Incomplete information, suspicious profile..."></textarea>
        <div style="display:flex;gap:10px;margin-top:16px;">
          <button onclick="confirmReject()" class="btn btn-danger" style="flex:1;">Reject</button>
          <button onclick="closeModal()" class="btn btn-ghost" style="flex:1;">Cancel</button>
        </div>
      </div>
    </div>

    <!-- Full Profile Modal -->
    <div id="profile-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1001;align-items:center;justify-content:center;">
      <div style="background:white;border-radius:20px;max-width:600px;width:95%;max-height:90vh;overflow-y:auto;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);">
        <div style="padding:28px 32px;border-bottom:1px solid #f3f4f6;">
          <div style="display:flex;align-items:center;gap:16px;justify-content:space-between;">
            <h3 style="font-weight:800;font-size:1.4rem;">Full Profile</h3>
            <button onclick="closeProfileModal()" style="width:36px;height:36px;border-radius:10px;background:#f3f4f6;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;" title="Close">
              <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
        </div>
        <div id="profile-content" style="padding:32px;"></div>
      </div>
    </div>

    <div id="tab-content">
      <div style="text-align:center;padding:60px;"><div class="spinner spinner-dark" style="width:36px;height:36px;border-width:3px;margin:0 auto;"></div></div>
    </div>
  </main>
</div>
<script src="assets/app.js?v=2"></script>
<script>
let pendingRejectId = null;
let currentUsers = [];

// Load stats on page load
(async () => {
    const {ok, data} = await api('api/admin/stats.php');
  if (!ok) return;
  ['totalUsers','verifiedUsers','pendingApprovals','totalRequests','totalMessages'].forEach(k => {
    const el = document.getElementById('stat-'+k);
    if (el) el.textContent = data[k] ?? 0;
  });
})();

async function loadTab(tab) {
  const content = document.getElementById('tab-content');
  content.innerHTML = '<div style="text-align:center;padding:60px;"><div class="spinner spinner-dark" style="width:36px;height:36px;border-width:3px;margin:0 auto;"></div></div>';

  if (tab === 'users') {
    const {ok, data} = await api('api/admin/users.php');
    currentUsers = data?.users ?? [];
    const users = currentUsers;
    if (!users.length) { content.innerHTML = '<div class="empty-state"><p>No users yet.</p></div>'; return; }
    content.innerHTML = `
      <div style="margin-bottom:14px;position:relative;">
        <svg style="position:absolute;left:12px;top:50%;transform:translateY(-50%);width:18px;height:18px;color:#9ca3af;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input id="user-search" type="text" class="input-field" style="padding-left:40px;" placeholder="Search users...">
      </div>
      <div class="table-wrap card" style="padding:0;">
        <table>
          <thead><tr><th>User</th><th>University / Dept</th><th>Roll No</th><th>Status</th><th>Verified</th><th>Actions</th></tr></thead>
          <tbody id="users-tbody">
          ${users.map(u => `<tr data-search="${escHtml(u.name)} ${escHtml(u.email)} ${escHtml(u.university||'')}">
            <td>
              <div style="display:flex;align-items:center;gap:10px;">
                <img src="${escHtml(u.image||'')}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;" onerror="this.src='https://via.placeholder.com/36'">
                <div><p style="font-weight:600;">${escHtml(u.name)}</p><p style="font-size:.78rem;color:#9ca3af;">${escHtml(u.email)}</p></div>
              </div>
            </td>
            <td><p style="font-size:.85rem;">${escHtml(u.university||'')}</p><p style="font-size:.78rem;color:#9ca3af;">${escHtml(u.department||'')} • ${escHtml(u.course||'')} </p></td>
            <td style="font-size:.85rem;">${escHtml(u.rollNo||'—')}</td>
            <td><span class="badge badge-${u.approvalStatus}">${u.approvalStatus}</span></td>
            <td>${u.isVerified ? '<span style="color:#16a34a;font-weight:700;">✓</span>' : '<span style="color:#9ca3af;">✗</span>'}</td>
            <td>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                ${u.approvalStatus!=='approved'?`<button type="button" onclick="adminAction('approve',${u.id},this)" class="btn btn-success btn-sm">Approve</button>`:''}
                ${u.approvalStatus!=='rejected'?`<button type="button" onclick="openRejectModal(${u.id})" class="btn btn-danger btn-sm">Reject</button>`:''}
                ${!u.isVerified?`<button type="button" onclick="adminAction('verify',${u.id},this)" class="btn btn-ghost btn-sm">Verify</button>`:''}
                ${!u.isAdmin?`<button type="button" onclick="adminAction('make-admin',${u.id},this)" class="btn btn-ghost btn-sm" style="font-size:.75rem;">Make Admin</button>`:'<span class="badge badge-admin">Admin</span>'}
                <button onclick="showUserProfile(${u.id})" class="btn btn-ghost btn-sm" style="font-size:.75rem;">View</button>
                <button type="button" onclick="adminAction('delete',${u.id},this,true)" class="btn btn-sm" style="background:#fee2e2;color:#dc2626;">Delete</button>
              </div>
            </td>
          </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
    document.getElementById('user-search').addEventListener('input', function() {
      const q = this.value.toLowerCase();
      document.querySelectorAll('#users-tbody tr').forEach(r => {
        r.style.display = r.dataset.search.toLowerCase().includes(q) ? '' : 'none';
      });
    });

  } else if (tab === 'requests') {
    const {data} = await api('api/admin/requests.php');
    const reqs = data?.requests ?? [];
    if (!reqs.length) { content.innerHTML = '<div class="empty-state"><p>No requests yet.</p></div>'; return; }
    content.innerHTML = `<div class="table-wrap card" style="padding:0;">
      <table>
        <thead><tr><th>Sender (Full)</th><th>Receiver (Full)</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>${reqs.map(r=>`<tr>
          <td>
            <div style="display:flex;align-items:flex-start;gap:8px;">
              <img src="${escHtml(r.senderImage||'')}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;" onerror="this.src='https://via.placeholder.com/32'">
              <div>
                <p style="font-weight:600;font-size:.88rem;">${escHtml(r.senderName)}</p>
                <p style="font-size:.75rem;color:#9ca3af;">${escHtml(r.senderEmail)}</p>
                <p style="font-size:.74rem;color:#6b7280;">${escHtml(r.senderUniversity||'N/A')}</p>
                <p style="font-size:.72rem;color:#9ca3af;">${escHtml(r.senderDepartment||'')} • ${escHtml(r.senderCourse||'')}</p>
                <p style="font-size:.72rem;color:#9ca3af;">Roll: ${escHtml(r.senderRollNo||'N/A')} | ${escHtml(r.senderShift||'N/A')} ${escHtml(r.senderSection||'')} / Sem ${escHtml(r.senderSemester||'N/A')}</p>
              </div>
            </div>
          </td>
          <td>
            <div style="display:flex;align-items:flex-start;gap:8px;">
              <img src="${escHtml(r.receiverImage||'')}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;" onerror="this.src='https://via.placeholder.com/32'">
              <div>
                <p style="font-weight:600;font-size:.88rem;">${escHtml(r.receiverName)}</p>
                <p style="font-size:.75rem;color:#9ca3af;">${escHtml(r.receiverEmail)}</p>
                <p style="font-size:.74rem;color:#6b7280;">${escHtml(r.receiverUniversity||'N/A')}</p>
                <p style="font-size:.72rem;color:#9ca3af;">${escHtml(r.receiverDepartment||'')} • ${escHtml(r.receiverCourse||'')}</p>
                <p style="font-size:.72rem;color:#9ca3af;">Roll: ${escHtml(r.receiverRollNo||'N/A')} | ${escHtml(r.receiverShift||'N/A')} ${escHtml(r.receiverSection||'')} / Sem ${escHtml(r.receiverSemester||'N/A')}</p>
              </div>
            </div>
          </td>
          <td><span class="badge badge-${r.status}">${r.status}</span></td>
          <td style="font-size:.82rem;color:#6b7280;">${new Date(r.createdAt).toLocaleDateString()}</td>
        </tr>`).join('')}</tbody>
      </table>
    </div>`;

  } else if (tab === 'messages') {
    const {data} = await api('api/admin/messages.php');
    const convs = data?.conversations ?? [];
    if (!convs.length) { content.innerHTML = '<div class="empty-state"><p>No messages yet.</p></div>'; return; }
    content.innerHTML = `<div class="card" style="padding:0;overflow:hidden;">
      ${convs.map(c=>`<div onclick="loadConversation(${c.requestId})" style="display:flex;align-items:center;gap:14px;padding:16px;border-bottom:1px solid #f3f4f6;cursor:pointer;transition:background .2s;" onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''">
        <div style="display:flex;gap:-8px;">
          <img src="${escHtml(c.senderImage||'')}" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid white;" onerror="this.src='https://via.placeholder.com/40'">
          <img src="${escHtml(c.receiverImage||'')}" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid white;margin-left:-12px;" onerror="this.src='https://via.placeholder.com/40'">
        </div>
        <div style="flex:1;">
          <p style="font-weight:600;font-size:.9rem;">${escHtml(c.senderName)} &amp; ${escHtml(c.receiverName)}</p>
          <p style="font-size:.78rem;color:#6b7280;">${escHtml(c.senderEmail||'')} → ${escHtml(c.receiverEmail||'')}</p>
          <p style="font-size:.8rem;color:#9ca3af;">${c.messageCount} messages • Last: ${new Date(c.lastMessageAt).toLocaleString()}</p>
          <p style="font-size:.8rem;color:#374151;margin-top:2px;">${escHtml((c.lastMessage || '').slice(0, 90))}</p>
        </div>
        <svg style="width:18px;height:18px;color:#9ca3af;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/></svg>
      </div>`).join('')}
    </div>`;
  }
}

async function loadConversation(requestId) {
  const content = document.getElementById('tab-content');
  content.innerHTML = '<div style="text-align:center;padding:60px;"><div class="spinner spinner-dark" style="width:36px;height:36px;border-width:3px;margin:0 auto;"></div></div>';
    const {ok, data} = await api(`api/admin/messages.php?request_id=${requestId}`);
  const msgs = data?.messages ?? [];
  content.innerHTML = `
    <div style="margin-bottom:12px;">
      <button onclick="loadTab('messages')" class="btn btn-ghost btn-sm">← Back to Conversations</button>
    </div>
    <div class="card" style="max-height:600px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding:20px;">
      ${msgs.length ? msgs.map(m=>{
        const time=new Date(m.createdAt).toLocaleString();
        return `<div style="display:flex;align-items:flex-start;gap:10px;">
          <img src="${escHtml(m.senderImage||'')}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;flex-shrink:0;" onerror="this.src='https://via.placeholder.com/32'">
          <div style="background:#f3f4f6;border-radius:12px;padding:10px 14px;max-width:70%;">
            <p style="font-size:.78rem;font-weight:600;color:#6b7280;margin-bottom:4px;">${escHtml(m.senderName)} • ${time}</p>
            <p style="font-size:.74rem;color:#9ca3af;margin-bottom:4px;">${escHtml(m.senderEmail||'')}</p>
            <p style="font-size:.9rem;">${escHtml(m.content)}</p>
          </div>
        </div>`;
      }).join('') : '<p style="text-align:center;color:#9ca3af;">No messages in this conversation.</p>'}
    </div>`;
}

async function adminAction(action, id, btn=null, useConfirm=false) {
  if (useConfirm && !window.confirm('Are you sure?')) return;
  const urls = {
    approve: `api/admin/approve.php?id=${id}`,
    verify: `api/admin/verify.php?id=${id}`,
    'make-admin': `api/admin/make-admin.php?id=${id}`,
    delete: `api/admin/delete.php?id=${id}`,
  };
  if (!urls[action]) { showToast('Invalid admin action', 'error'); return; }
  const originalText = btn ? btn.textContent : action;
  if (btn) { btn.disabled = true; btn.innerHTML = '...'; }
  try {
    const {ok,data} = await api(urls[action]);
    if (ok) {
      showToast(data.message||'Done!');
      loadTab('users');
    } else {
      showToast(data.error||'Failed','error');
      if (btn) { btn.disabled=false; btn.textContent=originalText; }
    }
  } catch (err) {
    showToast('Network error. Try again.','error');
    if (btn) { btn.disabled=false; btn.textContent=originalText; }
  }
}

function openRejectModal(id) {
  pendingRejectId = id;
  document.getElementById('reject-reason').value='';
  document.getElementById('reject-modal').style.display='flex';
}

function closeProfileModal() {
  document.getElementById('profile-modal').style.display='none';
}

function showUserProfile(id) {
  console.log('Users array:', currentUsers); // DEBUG
  console.log('Looking for ID:', id);
  const user = currentUsers.find(u => parseInt(u.id) === parseInt(id));
  if (!user) { 
    showToast('User not found - reload Users tab', 'error'); 
    console.error('No user found for ID:', id, 'Available IDs:', currentUsers.map(u=>u.id));
    return; 
  }
  
  const content = document.getElementById('profile-content');
  const approveBtn = user.approvalStatus !== 'approved' ? `<button onclick="adminAction('approve',${user.id},this);closeProfileModal();" class="btn btn-success" style="flex:1;">Approve</button>` : '';
  const rejectBtn = user.approvalStatus !== 'rejected' ? `<button onclick="openRejectModal(${user.id})" class="btn btn-danger" style="flex:1;">Reject</button>` : '';
  const verifyBtn = !user.isVerified ? `<button onclick="adminAction('verify',${user.id},this);closeProfileModal();" class="btn btn-ghost" style="flex:1;">Verify Email</button>` : '';
  const adminBtn = !user.isAdmin ? `<button onclick="adminAction('make-admin',${user.id},this);closeProfileModal();" class="btn btn-primary" style="flex:1;">Make Admin</button>` : '<span class="badge badge-admin">Admin</span>';
  
  content.innerHTML = `
    <div style="text-align:center;margin-bottom:28px;">
      <img src="${user.image || 'https://via.placeholder.com/120'}" style="width:120px;height:120px;border-radius:20px;object-fit:cover;border:4px solid #dbeafe;margin:0 auto;box-shadow:0 10px 25px rgba(0,0,0,.1);" onerror="this.src='https://via.placeholder.com/120'">
      <h4 style="font-size:1.5rem;font-weight:800;margin:12px 0 4px;">${user.name}</h4>
      <p style="color:#6b7280;font-size:1rem;">${user.email}</p>
    </div>
    
    <div style="display:grid;gap:12px;margin-bottom:24px;">
      <div><label style="font-weight:600;color:#374151;font-size:.9rem;">University</label><p style="font-size:.95rem;">${user.university || '—'}</p></div>
      <div><label style="font-weight:600;color:#374151;font-size:.9rem;">Department • Course</label><p style="font-size:.95rem;">${user.department || '—'} • ${user.course || '—'}</p></div>
      <div><label style="font-weight:600;color:#374151;font-size:.9rem;">Roll No / SAP ID</label><p style="font-size:.95rem;">${user.rollNo || '—'} ${user.sapId ? '/ ' + user.sapId : ''}</p></div>
      <div><label style="font-weight:600;color:#374151;font-size:.9rem;">Shift • Section • Semester</label><p style="font-size:.95rem;">${user.shift || '—'} • ${user.section || '—'} • ${user.semester || '—'}</p></div>
    </div>
    
    <div style="margin-bottom:24px;">
      <label style="font-weight:600;color:#374151;font-size:.9rem;display:block;margin-bottom:8px;">Why UniSync?</label>
      <p style="background:#f8fafc;border-left:4px solid #3b82f6;padding:16px;border-radius:0 8px 8px 0;font-size:.95rem;line-height:1.5;">${user.reason || 'No reason provided'}</p>
    </div>
    
    <div style="margin-bottom:24px;">
      <label style="font-weight:600;color:#374151;font-size:.9rem;display:block;margin-bottom:8px;">Qualities</label>
      <p style="font-size:.95rem;color:#6b7280;">${user.qualities ? user.qualities.split(',').map(q=>`<span style="background:#dbeafe;color:#1e40af;padding:4px 10px;border-radius:20px;font-size:.85rem;margin:2px;display:inline-block;">${q.trim()}</span>`).join('') : 'None listed'}</p>
    </div>
    
    <div style="display:flex;flex-wrap:wrap;gap:8px;font-size:.8rem;">
      <span class="badge badge-${user.approvalStatus}">${user.approvalStatus}</span>
      ${user.isVerified ? '<span class="badge badge-success">Verified</span>' : '<span class="badge badge-warning">Unverified</span>'}
      ${user.rejectionReason ? `<span class="badge badge-danger" style="max-width:200px;font-size:.75rem;" title="${user.rejectionReason}">Rejected: ${user.rejectionReason.substring(0,30)}${user.rejectionReason.length>30?'...' : ''}</span>` : ''}
      <span style="color:#6b7280;">Joined ${new Date(user.createdAt).toLocaleDateString()}</span>
    </div>
    
    ${approveBtn || rejectBtn || verifyBtn || adminBtn ? `<div style="display:flex;gap:10px;margin-top:24px;border-top:1px solid #f3f4f6;padding-top:20px;">
      ${approveBtn}${rejectBtn}${verifyBtn}${adminBtn}
    </div>` : ''}
  `;
  document.getElementById('profile-modal').style.display='flex';
}
function closeModal() { 
  document.getElementById('reject-modal').style.display='none'; 
  pendingRejectId=null; 
}

async function confirmReject() {
  const reason = document.getElementById('reject-reason').value.trim();
  if (!reason) { showToast('Reason is required','error'); return; }
  const {ok,data} = await api(`api/admin/reject.php?id=${pendingRejectId}`, 'POST', {reason});
  closeModal();
  if (ok) { showToast('User rejected.'); loadTab('users'); }
  else showToast(data.error||'Failed','error');
}

setupTabs('admin-tabs','tab-content',loadTab);
loadTab('users');
</script>
</body>
</html>
