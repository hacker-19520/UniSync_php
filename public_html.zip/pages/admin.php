<?php 
require_once '../includes/auth.php';
requireAdmin();
$pageTitle = 'Admin Dashboard';
$showSidebar = true;
include '../includes/header.php'; 
?>
<div class="min-h-screen lg:ml-64 p-8">
    <div class="mb-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Admin Dashboard</h1>
        <p class="text-xl text-red-600 font-semibold">Manage users, requests, and platform stats</p>
    </div>

    <!-- Stats -->
    <div class="grid lg:grid-cols-5 gap-6 mb-12">
        <?php
        $stats = [
            ['total' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(), 'icon' => 'fa-users', 'color' => 'blue'],
            ['pending' => $pdo->query("SELECT COUNT(*) FROM users WHERE approvalStatus = 'pending'")->fetchColumn(), 'icon' => 'fa-clock', 'color' => 'yellow'],
            ['verified' => $pdo->query("SELECT COUNT(*) FROM users WHERE isVerified = 1")->fetchColumn(), 'icon' => 'fa-check-circle', 'color' => 'green'],
            ['requests' => $pdo->query("SELECT COUNT(*) FROM requests")->fetchColumn(), 'icon' => 'fa-paper-plane', 'color' => 'purple'],
            ['messages' => $pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn(), 'icon' => 'fa-comments', 'color' => 'indigo']
        ];
        foreach ($stats as $stat): 
        ?>
        <div class="bg-white rounded-3xl shadow-xl p-8 text-center group hover:shadow-2xl transition-all">
            <i class="fas <?php echo $stat['icon']; ?> text-4xl text-<?php echo $stat['color']; ?>-600 mb-4 opacity-75"></i>
            <div class="text-3xl font-bold text-gray-900"><?php echo $stat[key($stat)]; ?></div>
            <div class="text-sm text-gray-600 capitalize"><?php echo strtolower(key($stat)); ?></div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="grid lg:grid-cols-3 gap-8">
        <!-- Pending Users -->
        <div class="lg:col-span-2 bg-white rounded-3xl shadow-xl p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i class="fas fa-user-clock mr-3 text-yellow-600"></i>Pending Approvals
            </h2>
            <div id="pending-users-loading" class="flex justify-center py-12">
                <i class="fas fa-spinner fa-spin text-3xl text-blue-600"></i>
            </div>
            <div id="pending-users-list" class="space-y-4 hidden"></div>
        </div>

        <!-- Quick Actions -->
        <div class="space-y-6">
            <div class="bg-gradient-to-r from-red-500 to-red-600 text-white p-8 rounded-3xl shadow-2xl">
                <h3 class="text-xl font-bold mb-6">Quick Actions</h3>
                <div class="space-y-3 text-sm">
                    <a href="#" onclick="loadStats()" class="block p-3 bg-red-500/20 rounded-xl hover:bg-red-500/40 transition-all">📊 View Full Stats</a>
                    <a href="#" onclick="refreshData()" class="block p-3 bg-red-500/20 rounded-xl hover:bg-red-500/40 transition-all">🔄 Refresh All</a>
                </div>
            </div>
            <div class="bg-white rounded-3xl shadow-xl p-8">
                <h3 class="text-xl font-bold text-gray-900 mb-6">Platform Stats</h3>
                <div id="admin-stats" class="space-y-4 text-sm"></div>
            </div>
        </div>
    </div>

    <!-- Tabs for Requests/Messages -->
    <div class="mt-12 bg-white rounded-3xl shadow-xl p-8">
        <div class="flex border-b mb-8">
            <button class="tab-btn px-8 py-4 font-bold text-lg border-b-4 border-blue-500 text-blue-600" onclick="showTab('requests')">Connection Requests <span id="requests-count" class="ml-2 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-bold">0</span></button>
            <button class="tab-btn px-8 py-4 font-bold text-lg border-b-2 border-gray-200 hover:text-blue-600" onclick="showTab('messages')">Messages <span id="messages-count" class="ml-2 bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-xs font-bold">0</span></button>
        </div>
        <div id="requests-tab">
            <div id="requests-loading" class="flex justify-center py-12">
                <i class="fas fa-spinner fa-spin text-4xl"></i>
            </div>
            <div id="requests-list" class="hidden"></div>
        </div>
        <div id="messages-tab" class="hidden">
            Coming soon...
        </div>
    </div>
</div>

<script src="/assets/app.js"></script>
<script>
let currentTab = 'requests';

loadAdminPage();

function getBasePath() {
    const path = window.location.pathname;
    if (path.includes('/pages/')) {
        return path.split('/pages/')[0] || '';
    }
    return path.substring(0, path.lastIndexOf('/'));
}

function buildApiUrl(path) {
    if (path.startsWith('http')) return path;
    const base = getBasePath().replace(/\/+$/, '');
    const cleanPath = path.replace(/^\/+/, '');
    return `${base}/${cleanPath}`;
}

async function apiRequest(url, options = {}) {
    const opts = { method: 'GET', headers: { 'Content-Type': 'application/json' }, ...options };
    if (opts.body && typeof opts.body !== 'string') {
        opts.body = JSON.stringify(opts.body);
    }
    const res = await fetch(buildApiUrl(url), opts);
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
}

function handleApiResponse(res) {
    if (res.ok) {
        if (typeof showToast === 'function') showToast(res.data?.message || 'Success');
        return true;
    }
    const errorMessage = res.data?.error || 'Action failed';
    if (typeof showToast === 'function') showToast(errorMessage, 'error');
    else alert(errorMessage);
    return false;
}

async function loadAdminPage() {
    const [statsRes, usersRes] = await Promise.all([
        apiRequest('/api/admin.php?action=stats'),
        apiRequest('/api/admin.php?action=users')
    ]);
    
    if (statsRes.ok) renderStats(statsRes.data);
    renderPendingUsers(usersRes.data?.users || []);
}

function renderStats(stats) {
    document.getElementById('admin-stats').innerHTML = `
        <div><strong>Total Users:</strong> ${stats.totalUsers}</div>
        <div><strong>Pending:</strong> ${stats.pendingApprovals}</div>
        <div><strong>Verified:</strong> ${stats.verifiedUsers}</div>
    `;
}

function renderPendingUsers(users) {
    const container = document.getElementById('pending-users-list');
    const loading = document.getElementById('pending-users-loading');
    
    const pending = users.filter(u => u.approvalStatus === 'pending');
    
    container.innerHTML = pending.map(user => `
        <div class="p-6 bg-gray-50 rounded-2xl border-2 border-gray-200 hover:border-yellow-300 transition-all group">
            <div class="flex items-start justify-between mb-4 gap-4">
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 rounded-2xl overflow-hidden border border-gray-200 bg-white flex items-center justify-center">
                      <img src="${user.image ? escHtml(user.image) : 'https://via.placeholder.com/64'}" alt="${escHtml(user.name)}" class="w-full h-full object-cover">
                    </div>
                    <div>
                        <h4 class="font-bold text-lg">${escHtml(user.name)}</h4>
                        <p class="text-sm text-gray-600">${escHtml(user.email)}</p>
                        <p class="text-sm text-gray-600">${escHtml(user.university)} • ${escHtml(user.department)}</p>
                    </div>
                </div>
                <div class="flex gap-2 flex-wrap opacity-0 group-hover:opacity-100 transition-all">
                    <button type="button" onclick="adminAction('approve', ${user.id})" class="bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700 text-sm font-bold transition-all">
                        <i class="fas fa-check mr-1"></i>Approve
                    </button>
                    <button type="button" onclick="showRejectModal(${user.id}, ${JSON.stringify(user.name)})" class="bg-yellow-600 text-white px-4 py-2 rounded-xl hover:bg-yellow-700 text-sm font-bold transition-all">
                        <i class="fas fa-times mr-1"></i>Reject
                    </button>
                    <button type="button" onclick="adminAction('delete', ${user.id}, true)" class="bg-red-600 text-white px-4 py-2 rounded-xl hover:bg-red-700 text-sm font-bold transition-all">
                        <i class="fas fa-trash mr-1"></i>Delete
                    </button>
                </div>
            </div>
            <div class="grid md:grid-cols-3 gap-4 text-sm">
                <div><strong>Roll No:</strong> ${escHtml(user.rollNo || 'N/A')}</div>
                <div><strong>SAP ID:</strong> ${escHtml(user.sapId || 'N/A')}</div>
                <div><strong>Course:</strong> ${escHtml(user.course || 'N/A')}</div>
                <div><strong>Shift:</strong> ${escHtml(user.shift || 'N/A')}</div>
                <div><strong>Section:</strong> ${escHtml(user.section || 'N/A')}</div>
                <div><strong>Semester:</strong> ${escHtml(user.semester || 'N/A')}</div>
                <div><strong>Verified:</strong> ${user.isVerified ? 'Yes' : 'No'}</div>
                <div><strong>Status:</strong> <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-bold">Pending</span></div>
            </div>
            <div class="mt-4 p-4 bg-blue-50 rounded-xl space-y-3 text-sm">
                <div><strong>Reason:</strong> ${escHtml(user.reason || 'N/A')}</div>
                <div><strong>Qualities / Niche:</strong> ${escHtml(user.qualities || 'N/A')}</div>
            </div>
        </div>
    `).join('') || '<p class="text-center py-12 text-gray-500">No pending approvals 🎉</p>';
    
    loading.classList.add('hidden');
    container.classList.remove('hidden');
}

async function adminAction(type, id, useConfirm = false) {
    if (useConfirm && !confirm(`Confirm ${type}?`)) return;
    const res = await apiRequest(`/api/admin.php?action=${type}&id=${id}`);
    if (handleApiResponse(res)) loadAdminPage();
}

async function showRejectModal(id, name) {
    const reason = prompt(`Reject ${name}? Reason:`);
    if (reason) {
        const res = await apiRequest(`/api/admin.php?action=reject&id=${id}`, {
            method: 'POST',
            body: { reason }
        });
        if (handleApiResponse(res)) loadAdminPage();
    }
}

function showTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('border-b-4', 'border-blue-500', 'text-blue-600'));
    event.target.classList.add('border-b-4', 'border-blue-500', 'text-blue-600');
    
    if (tab === 'requests') {
        document.getElementById('requests-tab').classList.remove('hidden');
        document.getElementById('messages-tab').classList.add('hidden');
    } else {
        document.getElementById('requests-tab').classList.add('hidden');
        document.getElementById('messages-tab').classList.remove('hidden');
    }
}

function refreshData() {
    loadAdminPage();
}
</script>

