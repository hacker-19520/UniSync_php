<?php 
$pageTitle = 'Login';
include '../includes/header.php'; 
?>
<div class="min-h-screen flex items-center justify-center py-12 px-4">
    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl p-12 space-y-8">
        <div class="text-center">
            <h2 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
            <p class="text-gray-600">Enter details to continue to your dashboard</p>
        </div>
        <div id="login-step1" class="space-y-6">
            <form action="../api/auth.php?action=login-request" method="POST" data-ajax class="space-y-6">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                    <input type="email" name="email" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 transition-all" placeholder="your.email@university.edu">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                    <input type="password" name="password" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 transition-all" placeholder="Your password">
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-4 rounded-xl text-xl font-bold hover:bg-blue-700 transition-all shadow-xl">
                    <i class="fas fa-sign-in-alt mr-2"></i>Continue with OTP
                </button>
            </form>
        </div>
        <div id="login-step2" class="space-y-6 hidden">
            <div class="text-center p-8 bg-blue-50 rounded-2xl">
                <i class="fas fa-envelope text-4xl text-blue-500 mb-4"></i>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Check your email</h3>
                <p class="text-gray-600" id="otp-email"></p>
            </div>
            <form action="../api/auth.php?action=verify-login-otp" method="POST" data-ajax class="space-y-6">
                <input type="hidden" name="email" id="verify-email">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Enter 6-digit code</label>
                    <input type="text" name="code" maxlength="6" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-center text-2xl tracking-widest font-mono" placeholder="123456">
                </div>
                <button type="submit" class="w-full bg-green-600 text-white py-4 rounded-xl text-xl font-bold hover:bg-green-700 transition-all shadow-xl">
                    <i class="fas fa-check mr-2"></i>Verify & Login
                </button>
                <button type="button" onclick="showStep1()" class="w-full text-blue-600 hover:text-blue-800 py-3 font-semibold transition-all">Wrong email? Go back</button>
            </form>
        </div>
        <div class="text-center text-sm text-gray-600 pt-8 border-t">
            <p>New here? <a href="signup.php" class="font-semibold text-blue-600 hover:underline">Create account</a></p>
            <p class="mt-2">Demo: admin@unisync.com / password</p>
        </div>
    </div>
</div>

<script>
let currentEmail = '';
function showStep2(email) {
    currentEmail = email;
    document.getElementById('login-step1').classList.add('hidden');
    document.getElementById('login-step2').classList.remove('hidden');
    document.getElementById('otp-email').textContent = email;
    document.getElementById('verify-email').value = email;
}
function showStep1() {
    document.getElementById('login-step1').classList.remove('hidden');
    document.getElementById('login-step2').classList.add('hidden');
}

// Auto show step2 on success
document.querySelector('#login-step1 form').addEventListener('submit', async e => {
    // Existing AJAX...
});
</script>

