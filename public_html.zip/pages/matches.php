<?php 
require_once '../includes/auth.php';
requireAuth();
$pageTitle = 'Find Matches';
$showSidebar = true;
include '../includes/header.php'; 
?>
<div class="min-h-screen lg:ml-64 p-8">
    <div class="mb-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Find Your Match</h1>
        <p class="text-xl text-gray-600">Connect with verified students from your university</p>
    </div>

    <div class="bg-white rounded-3xl shadow-2xl p-8 mb-8">
        <div class="flex flex-col lg:flex-row gap-4 mb-8">
            <input type="text" id="search" placeholder="Search by name, department, course..." class="flex-1 p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-lg">
            <button onclick="loadUsers()" class="bg-blue-600 text-white px-8 py-4 rounded-xl hover:bg-blue-700 font-bold transition-all shadow-lg">
                <i class="fas fa-search mr-2"></i>Search
            </button>
        </div>
        <div id="users-loading" class="flex justify-center py-12">
            <i class="fas fa-spinner fa-spin text-3xl text-blue-600"></i>
        </div>
        <div id="users-list" class="grid md:grid-cols-2 lg:grid-cols-3 gap-6 hidden"></div>
        <div id="no-users" class="text-center py-16 hidden">
            <i class="fas fa-users-slash text-6xl text-gray-400 mb-6"></i>
            <h3 class="text-2xl font-bold text-gray-600 mb-2">No matches yet</h3>
            <p class="text-gray-500">Complete your profile to see students from your university</p>
        </div>
    </div>

    <!-- My Requests Card -->
    <div class="grid lg:grid-cols-2 gap-8">
        <div class="bg-white rounded-3xl shadow-2xl p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i class="fas fa-paper-plane mr-3 text-blue-600"></i>Sent Requests
            </h2>
            <div id="my-requests" class="space-y-4"></div>
        </div>
        <div class="bg-white rounded-3xl shadow-2xl p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i class="fas fa-inbox mr-3 text-green-600"></i>Requests for Me
            </h2>
            <div id="requests-for-me" class="space-y-4"></div>
        </div>
    </div>
</div>

<script>
loadPage();
async function loadPage() {
    const [usersRes, myReqRes, incomingRes] = await Promise.all([
        apiRequest('/api/profile.php?action=users'),
        apiRequest('/api/match.php?action=my-requests'),
        apiRequest('/api/match.php?action=requests-for-me')
    ]);
    
    if (usersRes.success) renderUsers(usersRes.data.users);
    if (myReqRes.success) renderRequests(myReqRes.data.requests, 'my-requests', 'Sent to');
    if (incomingRes.success) renderRequests(incomingRes.data.requests, 'requests-for-me', 'From');
}

function renderUsers(users) {
    const container = document.getElementById('users-list');
    const loading = document.getElementById('users-loading');
    const noUsers = document.getElementById('no-users');
    
    if (users.length === 0) {
        loading.classList.add('hidden');
        noUsers.classList.remove('hidden');
        return;
    }
    
    container.innerHTML = users.map(user => `
        <div class="group bg-gray-50 rounded-2xl p-6 hover:shadow-xl transition-all hover:-translate-y-2 border-2 border-transparent hover:border-blue-200">
            <img src="${user.image}" alt="${user.name}" class="w-24 h-24 rounded-full mx-auto mb-4 object-cover shadow-lg group-hover:scale-105 transition-transform">
            <h3 class="text-xl font-bold text-gray-900 text-center mb-2">${user.name}</h3>
            <p class="text-blue-600 font-semibold text-center mb-4">${user.department} - ${user.course}</p>
            <p class="text-gray-600 text-sm text-center mb-6">${user.reason?.substring(0, 100)}...</p>
            <div class="flex justify-center space-x-2 opacity-0 group-hover:opacity-100 transition-all">
                <button onclick="sendRequest(${user.id})" class="bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700 shadow-lg transition-all">
                    <i class="fas fa-paper-plane mr-2"></i>Connect
                </button>
            </div>
        </div>
    `).join('');
    
    loading.classList.add('hidden');
    container.classList.remove('hidden');
}

async function sendRequest(userId) {
    if (confirm('Send connection request?')) {
        const res = await apiRequest('/api/match.php?action=request', {
            method: 'POST',
            body: JSON.stringify({ receiverId: userId })
        });
        handleApiResponse(res);
        loadPage(); // Refresh
    }
}

async function handleReq(id, action, btn) {
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
  const url = `/api/match/${action}.php?id=${id}`;
  const res = await apiRequest(url, {method: 'POST'});
  if (res.success) {
    loadPage();
  } else {
    btn.disabled = false;
    btn.innerHTML = action === 'accept' ? 'Accept' : 'Reject';
  }
}

function renderRequests(requests, containerId, label) {
    const container = document.getElementById(containerId);
    container.innerHTML = requests.map(req => `
        <div class="p-6 bg-gray-50 rounded-xl flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <img src="${req.image}" alt="${req.name}" class="w-16 h-16 rounded-full shadow-md">
                <div>
                    <h4 class="font-bold text-gray-900">${req.name}</h4>
                    <p class="text-sm text-gray-600">${label} ${req.university} • ${req.department}</p>
                </div>
            </div>
<div class="flex gap-2">
  <a href="/pages/profile.php?id=${req.senderId}" class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold hover:bg-blue-700 whitespace-nowrap">Full Profile</a>
  <button onclick="handleReq(${req.id},'accept',this)" class="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold hover:bg-green-700 whitespace-nowrap">Accept</button>
  <button onclick="handleReq(${req.id},'reject',this)" class="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold hover:bg-red-700 whitespace-nowrap">Reject</button>
</div>
        </div>
    `).join('') || '<p class="text-gray-500 text-center py-8">No requests</p>';
}

document.getElementById('search').addEventListener('input', debounce(loadUsers, 500));

async function loadUsers() {
    const query = document.getElementById('search').value;
    // Add search param to API/users later
    await loadPage();
}

function debounce(func, wait) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}\n</script>

