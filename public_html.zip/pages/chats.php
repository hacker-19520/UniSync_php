<?php 
require_once '../includes/auth.php';
requireAuth();
$pageTitle = 'Chats';
$showSidebar = true;
include '../includes/header.php'; 
?>
<div class="min-h-screen lg:ml-64 p-8">
    <div class="mb-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Messages</h1>
        <p class="text-xl text-gray-600">Your active conversations</p>
    </div>

    <div class="bg-white rounded-3xl shadow-2xl p-8 mb-8">
        <div id="chats-loading" class="flex justify-center py-16">
            <i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i>
        </div>
        <div id="chats-list" class="grid gap-4 hidden"></div>
        <div id="no-chats" class="text-center py-20 hidden">
            <i class="fas fa-comments text-8xl text-gray-300 mb-8"></i>
            <h3 class="text-3xl font-bold text-gray-500 mb-4">No conversations yet</h3>
            <p class="text-xl text-gray-400">Send connection requests and get accepted to start chatting!</p>
            <a href="matches.php" class="mt-8 inline-block bg-blue-600 text-white px-8 py-4 rounded-2xl text-xl font-bold hover:bg-blue-700 transition-all">
                <i class="fas fa-users mr-2"></i>Find Matches
            </a>
        </div>
    </div>
</div>

<script>
loadChats();

async function loadChats() {
    const res = await apiRequest('/api/match.php?action=my-matches');
    const container = document.getElementById('chats-list');
    const loading = document.getElementById('chats-loading');
    const noChats = document.getElementById('no-chats');
    
    if (!res.success || !res.data.matches.length) {
        loading.classList.add('hidden');
        noChats.classList.remove('hidden');
        return;
    }
    
    container.innerHTML = res.data.matches.map(chat => `
        <a href="chat.php?requestId=${chat.id}" class="group flex items-center p-6 rounded-2xl hover:bg-blue-50 transition-all border-2 border-transparent hover:border-blue-200 hover:shadow-xl">
            <div class="relative mr-4">
                <img src="${chat.matchImage}" alt="${chat.matchName}" class="w-16 h-16 rounded-full shadow-md object-cover">
                <div class="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-3 border-white rounded-full"></div>
            </div>
            <div class="flex-1 min-w-0">
                <h3 class="font-bold text-lg text-gray-900 group-hover:text-blue-600 truncate">${chat.matchName}</h3>
                <p class="text-sm text-gray-500 truncate">${chat.university} • ${chat.department}</p>
            </div>
            <div class="text-right ml-4">
                <div class="text-xs text-gray-400 mb-1">2 min ago</div>
                <div class="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">3</div>
            </div>
            <i class="fas fa-chevron-right ml-4 text-gray-400 group-hover:text-blue-600"></i>
        </a>
    `).join('');
    
    loading.classList.add('hidden');
    container.classList.remove('hidden');
}
</script>

