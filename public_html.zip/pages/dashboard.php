<?php 
require_once '../includes/auth.php';
requireAuth();
$pageTitle = 'Dashboard';
$showSidebar = true;
include '../includes/header.php'; 

$userId = getCurrentUserId();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Stats
$stmt = $pdo->prepare("SELECT COUNT(*) as requests_sent FROM requests WHERE senderId = ?", 
                     "SELECT COUNT(*) as requests_received FROM requests WHERE receiverId = ? AND status = 'pending'",
                     "SELECT COUNT(*) as matches FROM requests WHERE status = 'accepted' AND (senderId = ? OR receiverId = ?)",
                     "SELECT COUNT(*) as messages FROM messages WHERE senderId = ?");
$stmt->execute([$userId]); $stats['sent'] = $stmt->fetchColumn();
$stmt->execute([$userId]); $stats['incoming'] = $stmt->fetchColumn();
$stmt->execute([$userId, $userId]); $stats['matches'] = $stmt->fetchColumn();
$stmt->execute([$userId]); $stats['messages'] = $stmt->fetchColumn();
?>
<div class="min-h-screen lg:ml-64 p-8">
    <div class="mb-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</h1>
        <p class="text-xl text-gray-600"><?php echo $user['university']; ?> • <?php echo $user['department']; ?></p>
    </div>

    <!-- Stats Cards -->
    <div class="grid lg:grid-cols-4 gap-6 mb-12">
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-8 rounded-3xl shadow-2xl group hover:scale-105 transition-all">
            <i class="fas fa-paper-plane text-3xl opacity-75 mb-4"></i>
            <div class="text-3xl font-bold"><?php echo $stats['sent']; ?></div>
            <div class="opacity-90">Requests Sent</div>
        </div>
        <div class="bg-gradient-to-br from-green-500 to-green-600 text-white p-8 rounded-3xl shadow-2xl group hover:scale-105 transition-all">
            <i class="fas fa-inbox text-3xl opacity-75 mb-4"></i>
            <div class="text-3xl font-bold"><?php echo $stats['incoming']; ?></div>
            <div class="opacity-90">New Requests</div>
        </div>
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-8 rounded-3xl shadow-2xl group hover:scale-105 transition-all">
            <i class="fas fa-heart text-3xl opacity-75 mb-4"></i>
            <div class="text-3xl font-bold"><?php echo $stats['matches']; ?></div>
            <div class="opacity-90">Active Matches</div>
        </div>
        <div class="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white p-8 rounded-3xl shadow-2xl group hover:scale-105 transition-all">
            <i class="fas fa-comments text-3xl opacity-75 mb-4"></i>
            <div class="text-3xl font-bold"><?php echo $stats['messages']; ?></div>
            <div class="opacity-90">Messages Sent</div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid lg:grid-cols-3 gap-8 mb-12">
        <a href="matches.php" class="block bg-white rounded-3xl shadow-xl p-10 text-center group hover:shadow-2xl transition-all hover:-translate-y-2">
            <i class="fas fa-users text-4xl text-blue-600 mb-6 group-hover:scale-110 transition-transform"></i>
            <h3 class="text-2xl font-bold text-gray-900 mb-4">Find New Matches</h3>
            <p class="text-gray-600 text-lg">Browse students from your university</p>
        </a>
        <a href="chats.php" class="block bg-white rounded-3xl shadow-xl p-10 text-center group hover:shadow-2xl transition-all hover:-translate-y-2">
            <i class="fas fa-comments text-4xl text-green-600 mb-6 group-hover:scale-110 transition-transform"></i>
            <h3 class="text-2xl font-bold text-gray-900 mb-4">My Messages</h3>
            <p class="text-gray-600 text-lg">Continue your conversations</p>
        </a>
        <a href="profile.php" class="block bg-white rounded-3xl shadow-xl p-10 text-center group hover:shadow-2xl transition-all hover:-translate-y-2">
            <i class="fas fa-user-edit text-4xl text-purple-600 mb-6 group-hover:scale-110 transition-transform"></i>
            <h3 class="text-2xl font-bold text-gray-900 mb-4">Update Profile</h3>
            <p class="text-gray-600 text-lg">Perfect your profile for better matches</p>
        </a>
    </div>

    <?php if (isAdmin()): ?>
    <div class="bg-red-50 border-2 border-red-200 rounded-3xl p-8">
        <div class="flex items-center mb-6">
            <i class="fas fa-crown text-3xl text-red-600 mr-4"></i>
            <h2 class="text-2xl font-bold text-red-900">Admin Panel</h2>
        </div>
        <a href="admin.php" class="bg-red-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-red-700 transition-all inline-flex items-center">
            <i class="fas fa-shield-alt mr-3"></i>Open Admin Dashboard
        </a>
    </div>
    <?php endif; ?>
</div>

