<?php 
require_once '../includes/auth.php';
requireAuth();
$pageTitle = 'Profile';
$showSidebar = true;
include '../includes/header.php'; 

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([getCurrentUserId()]);
$user = $stmt->fetch();
if (!$user) die('User not found');
?>
<div class="min-h-screen lg:ml-64 p-8">
    <div class="max-w-2xl">
        <div class="bg-white rounded-3xl shadow-2xl p-12 mb-12">
            <div class="text-center mb-12">
                <img src="<?php echo htmlspecialchars($user['image']); ?>" alt="<?php echo htmlspecialchars($user['name']); ?>" class="w-32 h-32 rounded-full mx-auto shadow-2xl mb-6 object-cover">
                <h1 class="text-4xl font-bold text-gray-900 mb-2"><?php echo htmlspecialchars($user['name']); ?></h1>
                <p class="text-2xl text-gray-600"><?php echo htmlspecialchars($user['university']); ?></p>
            </div>
            <div class="grid md:grid-cols-2 gap-8">
                <div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Academic Info</h3>
                    <div class="space-y-3 text-lg">
                        <div><strong>Department:</strong> <?php echo htmlspecialchars($user['department']); ?></div>
                        <div><strong>Course:</strong> <?php echo htmlspecialchars($user['course']); ?></div>
                        <?php if ($user['rollNo']): ?><div><strong>Roll No:</strong> <?php echo htmlspecialchars($user['rollNo']); ?></div><?php endif; ?>
                        <?php if ($user['sapId']): ?><div><strong>SAP ID:</strong> <?php echo htmlspecialchars($user['sapId']); ?></div><?php endif; ?>
                        <div><strong>Semester:</strong> <?php echo htmlspecialchars($user['semester'] ?? 'N/A'); ?></div>
                        <div><strong>Shift:</strong> <?php echo htmlspecialchars($user['shift'] ?? 'N/A'); ?></div>
                        <div><strong>Section:</strong> <?php echo htmlspecialchars($user['section'] ?? 'N/A'); ?></div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">About</h3>
                    <div class="space-y-4">
                        <div>
                            <strong>Why UniSync?</strong>
                            <p class="text-gray-700 mt-2"><?php echo nl2br(htmlspecialchars($user['reason'])); ?></p>
                        </div>
                        <?php if ($user['qualities']): ?>
                        <div>
                            <strong>Qualities:</strong>
                            <p class="mt-2"><?php echo htmlspecialchars($user['qualities']); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Form -->
        <div class="bg-white rounded-3xl shadow-2xl p-12">
            <h2 class="text-3xl font-bold text-gray-900 mb-8 text-center">Edit Profile</h2>
            <form action="../api/profile.php?action=update" method="POST" data-ajax class="grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-semibold mb-2">Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">University</label>
                    <input type="text" name="university" value="<?php echo htmlspecialchars($user['university']); ?>" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">Department</label>
                    <input type="text" name="department" value="<?php echo htmlspecialchars($user['department']); ?>" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">Course</label>
                    <input type="text" name="course" value="<?php echo htmlspecialchars($user['course']); ?>" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">Shift</label>
                    <select name="shift" class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                        <option <?php echo ($user['shift'] == 'Morning') ? 'selected' : ''; ?>>Morning</option>
                        <option <?php echo ($user['shift'] == 'Afternoon') ? 'selected' : ''; ?>>Afternoon</option>
                        <option <?php echo ($user['shift'] == 'Evening') ? 'selected' : ''; ?>>Evening</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">Section</label>
                    <input type="text" name="section" value="<?php echo htmlspecialchars($user['section']); ?>" class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-2">Semester</label>
                    <input type="text" name="semester" value="<?php echo htmlspecialchars($user['semester']); ?>" class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold mb-2">Profile Image URL</label>
                    <input type="url" name="image" value="<?php echo htmlspecialchars($user['image']); ?>" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold mb-2">Why UniSync?</label>
                    <textarea name="reason" rows="3" required class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($user['reason']); ?></textarea>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold mb-2">Qualities (comma separated)</label>
                    <input type="text" name="qualities" value="<?php echo htmlspecialchars($user['qualities']); ?>" class="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                </div>
                <button type="submit" class="md:col-span-2 w-full bg-blue-600 text-white py-4 rounded-xl text-xl font-bold hover:bg-blue-700 shadow-xl transition-all">
                    <i class="fas fa-save mr-2"></i>Update Profile
                </button>
            </form>
        </div>
    </div>
</div>

