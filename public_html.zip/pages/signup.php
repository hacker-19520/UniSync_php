<?php 
$pageTitle = 'Sign Up';
include '../includes/header.php'; 
?>
<div class="min-h-screen flex items-center justify-center py-12 px-4">
    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl p-12 space-y-8">
        <div>
            <h2 class="text-3xl font-bold text-center text-gray-900">Create Account</h2>
            <p class="text-center text-gray-600 mt-2">Join UniSync - Find your perfect study duo!</p>
        </div>
        <form action="../api/auth.php?action=register" method="POST" data-ajax class="space-y-6">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Full Name *</label>
                <input type="text" name="name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Your full name">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                <input type="email" name="email" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="your.email@university.edu">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Password *</label>
                <input type="password" name="password" required minlength="6" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Strong password">
            </div>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Roll No / ID *</label>
                    <input type="text" name="rollNo" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Your roll number">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">SAP ID</label>
                    <input type="text" name="sapId" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="SAP ID (optional)">
                </div>
            </div>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">University *</label>
                    <input type="text" name="university" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Your university">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Department *</label>
                    <input type="text" name="department" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Computer Science">
                </div>
            </div>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Course *</label>
                    <input type="text" name="course" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="BS Software Engineering">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Shift</label>
                    <select name="shift" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                        <option>Morning</option>
                        <option>Afternoon</option>
                        <option>Evening</option>
                    </select>
                </div>
            </div>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Section</label>
                    <input type="text" name="section" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="A">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Semester</label>
                    <input type="text" name="semester" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Fall 2024">
                </div>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Profile Image URL *</label>
                <input type="url" name="image" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="https://images.unsplash.com/photo-...">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Why UniSync? (What are you looking for?)*</label>
                <textarea name="reason" required rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-vertical" placeholder="Study partner for projects, someone in same course..."></textarea>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Your Qualities (comma separated)</label>
                <input type="text" name="qualities" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" placeholder="Hardworking, punctual, team player">
            </div>
            <button type="submit" data-original-text="Create Account" class="w-full bg-blue-600 text-white py-4 px-8 rounded-xl text-xl font-bold hover:bg-blue-700 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:-translate-y-1">
                <i class="fas fa-user-plus mr-2"></i>Create Account
            </button>
        </form>
        <div class="text-center text-sm text-gray-600 space-y-4">
            <p>By signing up, you agree to our <a href="#" class="text-blue-600 hover:underline">Terms</a> and <a href="#" class="text-blue-600 hover:underline">Privacy Policy</a></p>
            <p>Already have an account? <a href="login.php" class="font-semibold text-blue-600 hover:underline">Login here</a></p>
        </div>
        <div class="text-xs text-center text-gray-500 pt-8 border-t">
            <p>Admin will review your account within 24 hours. You'll get email notification!</p>
        </div>
    </div>
</div>

