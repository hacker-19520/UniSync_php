<?php 
require_once '../includes/auth.php';
requireAuth();
$pageTitle = 'Chat';
$showSidebar = true;
$requestId = (int)($_GET['requestId'] ?? 0);
if (!$requestId) die('No chat ID');
include '../includes/header.php'; 

// Get chat details
$stmt = $pdo->prepare("SELECT r.*, u1.name as senderName, u1.image as senderImage, u2.name as receiverName, u2.image as receiverImage 
                       FROM requests r 
                       JOIN users u1 ON r.senderId = u1.id 
                       JOIN users u2 ON r.receiverId = u2.id 
                       WHERE r.id = ? AND r.status = 'accepted' AND (r.senderId = ? OR r.receiverId = ?) ");
$stmt->execute([$requestId, getCurrentUserId(), getCurrentUserId()]);
$chat = $stmt->fetch();
if (!$chat) die('Chat not found or access denied');
?>
<div class="min-h-screen lg:ml-64 flex flex-col bg-gray-50">
    <!-- Chat Header -->
    <div class="bg-white border-b-2 border-gray-200 p-6 lg:p-8">
        <div class="flex items-center space-x-4">
            <img src="<?php echo htmlspecialchars($chat[getCurrentUserId() == $chat['senderId'] ? 'receiverImage' : 'senderImage']); ?>" alt="" class="w-14 h-14 rounded-full shadow-md">
            <div>
                <h2 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($chat[getCurrentUserId() == $chat['senderId'] ? 'receiverName' : 'senderName']); ?></h2>
                <p class="text-green-600 font-semibold">Online</p>
            </div>
        </div>
    </div>

    <!-- Messages -->
    <div id="messages-container" class="flex-1 p-6 lg:p-8 overflow-y-auto bg-gradient-to-b from-gray-50 to-white">
        <div id="messages-<?php echo $requestId; ?>" class="max-w-4xl mx-auto space-y-4 pb-20"></div>
    </div>

    <!-- Input -->
    <div class="bg-white border-t-2 border-gray-200 p-6 lg:p-8">
        <form class="chat-form max-w-4xl mx-auto" data-request-id="<?php echo $requestId; ?>">
            <div class="flex space-x-4">
                <div class="flex-1 relative">
                    <input type="text" name="content" placeholder="Type a message..." class="w-full p-4 pr-16 border-2 border-gray-200 rounded-3xl focus:border-blue-500 focus:outline-none text-lg resize-none" autocomplete="off">
                    <button type="submit" class="absolute right-4 top-1/2 -translate-y-1/2 bg-blue-600 text-white p-3 rounded-2xl hover:bg-blue-700 transition-all shadow-lg">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
const requestId = <?php echo $requestId; ?>;
startChatPoll(requestId);
loadMessages();

async function loadMessages() {
    const res = await apiRequest(`/api/chat.php?action=get&requestId=${requestId}`);
    if (res.success) {
        updateMessages(res.data.messages, requestId);
    }
}

setTimeout(loadMessages, 100); // Initial load
</script>

