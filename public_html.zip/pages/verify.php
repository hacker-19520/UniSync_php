<?php 
$pageTitle = 'Verify Email';
include '../includes/header.php'; 
?>
<div class="min-h-screen flex items-center justify-center py-12 px-4">
    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl p-12 space-y-8">
        <div class="text-center">
            <i class="fas fa-envelope-open-text text-6xl text-blue-500 mb-6"></i>
            <h2 class="text-3xl font-bold text-gray-900 mb-2">Verify Email</h2>
            <p class="text-gray-600">Enter the 6-digit code sent to your email</p>
        </div>
        <form action="../api/auth.php?action=verify-otp" method="POST" data-ajax class="space-y-6">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-4 text-center">
                    <span class="text-lg">Code sent to:</span><br>
                    <span class="font-mono text-blue-600" id="email-display"><?php echo htmlspecialchars($_GET['email'] ?? ''); ?></span>
                </label>
                <div class="flex gap-3 justify-center">
                    <input type="text" name="code1" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                    <input type="text" name="code2" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                    <input type="text" name="code3" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                    <input type="text" name="code4" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                    <input type="text" name="code5" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                    <input type="text" name="code6" maxlength="1" class="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 ring-blue-100 transition-all" autocomplete="one-time-code">
                </div>
                <input type="hidden" name="code" id="code-hidden">
            </div>
            <div class="text-center">
                <button type="button" onclick="resendOTP()" class="text-blue-600 hover:text-blue-800 font-semibold transition-colors">Didn't get code? Resend</button>
            </div>
            <button type="submit" class="w-full bg-green-600 text-white py-4 rounded-xl text-xl font-bold hover:bg-green-700 transition-all shadow-xl">
                <i class="fas fa-check-circle mr-2"></i>Verify Email
            </button>
        </form>
        <div class="text-center text-sm text-gray-500 pt-8 border-t">
            <p>Having trouble? Use demo <a href="../pages/login.php" class="text-blue-600 hover:underline">login</a></p>
        </div>
    </div>
</div>

<script>
const codeInputs = document.querySelectorAll('input[name^=code]');
codeInputs.forEach((input, index) => {
    input.addEventListener('input', (e) => {
        if (e.target.value.length === 1 && index < 5) {
            codeInputs[index + 1].focus();
        }
        document.getElementById('code-hidden').value = Array.from(codeInputs).map(i => i.value).join('');
    });
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
            codeInputs[index - 1].focus();
        }
    });
});

async function resendOTP() {
    const email = new URLSearchParams(window.location.search).get('email');
    const res = await apiRequest('../api/auth.php?action=send-otp', {
        method: 'POST',
        body: JSON.stringify({ email, name: 'User' })
    });
    handleApiResponse(res);
}
</script>

