<?php
// UniSync DB Setup - FIXED VERSION
require_once 'includes/config.php';

$host = DB_HOST;
$db = DB_NAME;
$user = DB_USER;
$pass = DB_PASS;

echo "<!DOCTYPE html>
<html>
<head>
<title>UniSync Setup</title>
<style>
body{font-family:system-ui;margin:0;padding:50px;background:#f8fafc;color:#1e293b}
.card{max-width:600px;margin:auto;padding:40px;background:white;border-radius:20px;box-shadow:0 25px 50px -12px rgba(0,0,0,.25)}
h1{color:#059669;font-size:2.5rem;text-align:center;margin-bottom:30px}
.success{color:#059669} .error{color:#dc2626}
button{display:block;margin:20px auto;padding:15px 40px;background:#3b82f6;color:white;border:none;border-radius:12px;font-weight:600;font-size:1.1rem;cursor:pointer;transition:all .3s}
button:hover{transform:translateY(-2px);box-shadow:0 10px 25px rgba(59,130,246,.4)}
</style>
</head>
<body>
<div class='card'>
<h1>🚀 UniSync DB Setup</h1>";

try {
    $pdo = new PDO('mysql:host=' . $host, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $db . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . $db . '`');
    
    $schema = file_get_contents('unisync_db.sql');
    $pdo->exec($schema);
    
    $admin_hash = password_hash('Macnitosh@12', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO `users` (`name`, `email`, `password`, `university`, `department`, `course`, `image`, `reason`, `isVerified`, `isAdmin`, `approvalStatus`) VALUES 
    ('Ahmad Bilal', 'ahmadbilal9436@gmail.com', '$admin_hash', 'Emerson University', 'Software Engineering', 'BS SE', 'https://ui-avatars.com/api/?name=Ahmad+Bilal&size=128&background=2563eb&color=fff', 'Admin', 1, 1, 'approved') 
    ON DUPLICATE KEY UPDATE `isVerified` = 1, `isAdmin` = 1, `approvalStatus` = 'approved', `password` = '$admin_hash'");
    
    $pdo->exec("INSERT INTO `otp_codes` (`email`, `code`, `expiresAt`) VALUES ('ahmadbilal9436@gmail.com', '831102', DATE_ADD(NOW(), INTERVAL 1 HOUR)) 
    ON DUPLICATE KEY UPDATE `code` = '831102', `expiresAt` = DATE_ADD(NOW(), INTERVAL 1 HOUR)");

    echo "<div class='success'>
    <h2>✅ COMPLETE!</h2>
    <p><strong>DB:</strong> $db created + tables</p>
    <ul style='background:#d1fae5;padding:20px;border-radius:12px;text-align:left;'>
        <li><strong>Email:</strong> ahmadbilal9436@gmail.com</li>
        <li><strong>Pass:</strong> Macnitosh@12</li>
        <li><strong>OTP:</strong> 831102</li>
    </ul>
    <a href='index.php'><button>🎉 Launch UniSync</button></a>
    <p style='color:#64748b;font-size:.9em;'>DELETE this file after upload</p>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='error'>
    <h2>❌ Error: " . htmlspecialchars($e->getMessage()) . "</h2>
    <p>Check config.php creds, Hostinger phpMyAdmin DB exists?</p>
    </div>";
}
echo "</div></body></html>";
?>

