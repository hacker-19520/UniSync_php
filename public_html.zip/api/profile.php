<?php
require_once '../includes/functions.php';
require_once '../includes/auth.php';

$action = $_GET['action'] ?? '';
$userId = getCurrentUserId();
if (!$userId) apiResponse(false, null, 'Unauthorized');

switch ($action) {
    case 'me':
        $stmt = $pdo->prepare("SELECT id, name, email, rollNo, sapId, university, department, course, shift, section, semester, image, reason, qualities, createdAt FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        apiResponse(true, ['user' => $user ?: null]);
        break;

    case 'update':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $allowed = ['name', 'university', 'department', 'course', 'shift', 'section', 'semester', 'image', 'reason', 'qualities'];
        $updates = [];
        $params = [];

        foreach ($allowed as $field) {
            if (isset($input[$field])) {
                $updates[] = "`$field` = ?";
                $params[] = sanitize($input[$field]);
            }
        }
        $params[] = $userId;
        
        if (empty($updates)) apiResponse(false, null, 'No fields to update');
        
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        apiResponse(true, null, 'Profile updated!');
        break;

    case 'users':
        $stmt = $pdo->prepare("SELECT id, name, rollNo, sapId, university, department, course, shift, section, semester, image, reason, qualities 
                               FROM users WHERE id != ? AND isVerified = 1 AND university = (SELECT university FROM users WHERE id = ?) 
                               ORDER BY createdAt DESC");
        $stmt->execute([$userId, $userId]);
        $users = $stmt->fetchAll();
        apiResponse(true, ['users' => $users]);
        break;

    default:
        apiResponse(false, null, 'Invalid action');
}
?>

