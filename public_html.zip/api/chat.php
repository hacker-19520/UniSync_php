<?php
require_once '../includes/functions.php';
require_once '../includes/auth.php';
requireAuth();

$action = $_GET['action'] ?? '';
$userId = getCurrentUserId();
$requestId = (int)($_GET['requestId'] ?? 0);

if (!$requestId) apiResponse(false, null, 'Request ID required');

switch ($action) {
    case 'send':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $content = trim(sanitize($input['content'] ?? ''));
        
        if (empty($content)) apiResponse(false, null, 'Message required');
        
        // Check access
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND status = 'accepted' AND (senderId = ? OR receiverId = ?)");
        $stmt->execute([$requestId, $userId, $userId]);
        if (!$stmt->fetch()) apiResponse(false, null, 'Cannot message - not accepted match');
        
        $stmt = $pdo->prepare("INSERT INTO messages (requestId, senderId, content) VALUES (?, ?, ?)");
        $stmt->execute([$requestId, $userId, $content]);
        apiResponse(true, ['messageId' => $pdo->lastInsertId()], 'Message sent!');
        break;

    case 'get':
        // Check access
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND status = 'accepted' AND (senderId = ? OR receiverId = ?)");
        $stmt->execute([$requestId, $userId, $userId]);
        if (!$stmt->fetch()) apiResponse(false, null, 'No access to chat');
        
        $stmt = $pdo->prepare("SELECT m.*, u.name as senderName, u.image as senderImage FROM messages m JOIN users u ON m.senderId = u.id WHERE m.requestId = ? ORDER BY m.createdAt ASC");
        $stmt->execute([$requestId]);
        apiResponse(true, ['messages' => $stmt->fetchAll()]);
        break;

    default:
        apiResponse(false, null, 'Invalid action');
}
?>

