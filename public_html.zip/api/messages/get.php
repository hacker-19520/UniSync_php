<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$requestId=(int)($_GET['request_id']??0);
$after=(int)($_GET['after']??0);
$userId=(int)$_SESSION['user_id'];
// Verify user is part of this accepted match
$stmt=$conn->prepare("SELECT * FROM requests WHERE id=? AND status='accepted' AND (senderId=? OR receiverId=?)");
$stmt->bind_param("iii",$requestId,$userId,$userId); $stmt->execute();
if ($stmt->get_result()->num_rows===0) { json_response(['error'=>'Access denied.'],403); }
$stmt->close();
$stmt=$conn->prepare("SELECT m.id,m.requestId,m.senderId,m.content,m.createdAt,u.name as sendername,u.image as senderimage FROM messages m JOIN users u ON m.senderId=u.id WHERE m.requestId=? AND m.id>? ORDER BY m.createdAt ASC");
$stmt->bind_param("ii",$requestId,$after); $stmt->execute();
$msgs=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
json_response(['messages'=>$msgs]);
