<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
if ($_SERVER['REQUEST_METHOD']!=='POST') { json_response(['error'=>'Method not allowed'],405); }
$data=json_decode(file_get_contents('php://input'),true);
$requestId=(int)($data['requestId']??0);
$content=trim($data['content']??'');
$senderId=(int)$_SESSION['user_id'];
if (!$content) { json_response(['error'=>'Message content required.'],400); }
$stmt=$conn->prepare("SELECT * FROM requests WHERE id=? AND status='accepted' AND (senderId=? OR receiverId=?)");
$stmt->bind_param("iii",$requestId,$senderId,$senderId); $stmt->execute();
if ($stmt->get_result()->num_rows===0) { json_response(['error'=>'You can only message accepted matches.'],403); }
$stmt->close();
$stmt=$conn->prepare("INSERT INTO messages (requestId,senderId,content) VALUES (?,?,?)");
$stmt->bind_param("iis",$requestId,$senderId,$content);
if ($stmt->execute()) {
  $msgId=$conn->insert_id;
  $stmt2=$conn->prepare("SELECT m.id,m.requestId,m.senderId,m.content,m.createdAt,u.name as sendername,u.image as senderimage FROM messages m JOIN users u ON m.senderId=u.id WHERE m.id=?");
  $stmt2->bind_param("i",$msgId); $stmt2->execute();
  $msg=$stmt2->get_result()->fetch_assoc(); $stmt2->close();
  json_response(['message'=>'Message sent.','data'=>$msg],201);
} else { json_response(['error'=>'Failed to send.'],500); }
$stmt->close();
