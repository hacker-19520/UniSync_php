<?php
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_response(['error'=>'Method not allowed'],405); }
$data = json_decode(file_get_contents('php://input'), true);
$email=$data['email']??''; $code=$data['code']??'';
if (!$email||!$code) { json_response(['error'=>'Email and OTP required.'],400); }
$stmt=$conn->prepare("SELECT * FROM otp_codes WHERE email=? ORDER BY createdAt DESC LIMIT 1");
$stmt->bind_param("s",$email); $stmt->execute();
$row=$stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$row) { json_response(['error'=>'OTP not found. Please request a new one.'],400); }
if (strtotime($row['expiresAt']) < time()) { json_response(['error'=>'OTP expired.'],400); }
if ($row['code'] !== $code) { json_response(['error'=>'Invalid OTP.'],400); }
$stmt=$conn->prepare("UPDATE users SET isVerified=1 WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute(); $stmt->close();
$stmt=$conn->prepare("DELETE FROM otp_codes WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute(); $stmt->close();
json_response(['message'=>'Email verified successfully.']);
