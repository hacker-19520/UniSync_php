<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_response(['error'=>'Method not allowed'],405); }
$data = json_decode(file_get_contents('php://input'), true);
$email=$data['email']??''; $password=$data['password']??'';
if (!$email||!$password) { json_response(['error'=>'Email and password required.'],400); }
$stmt=$conn->prepare("SELECT * FROM users WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute();
$user=$stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$user||!password_verify($password,$user['password'])) { json_response(['error'=>'Invalid credentials.'],400); }
if (!$user['isVerified']) { json_response(['error'=>'Please verify your email first.'],400); }
if ($user['approvalStatus']==='rejected') { json_response(['error'=>'Your account has been rejected.','rejectionReason'=>$user['rejectionReason'],'approvalStatus'=>'rejected'],403); }
if ($user['approvalStatus']==='pending') { json_response(['error'=>'Your account is pending admin approval.','approvalStatus'=>'pending'],403); }
$otp = generate_otp();
$expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));
$stmt=$conn->prepare("DELETE FROM otp_codes WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute(); $stmt->close();
$stmt=$conn->prepare("INSERT INTO otp_codes (email,code,expiresAt) VALUES (?,?,?)"); $stmt->bind_param("sss",$email,$otp,$expiresAt); $stmt->execute(); $stmt->close();
send_otp_email($email,$otp,$user['name'],'login');
json_response(['message'=>'OTP sent to your email.','requiresOtp'=>true,'mockOtp'=>$otp]);
