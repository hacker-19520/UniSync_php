<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_response(['error'=>'Method not allowed'],405); }

$data = json_decode(file_get_contents('php://input'), true);
$name=$data['name']??''; $email=$data['email']??''; $password=$data['password']??'';
$university=$data['university']??''; $department=$data['department']??'';
$course=$data['course']??''; $reason=$data['reason']??''; $image=$data['image']??'';
$rollNo=$data['rollNo']??null; $sapId=$data['sapId']??null;
$shift=$data['shift']??null; $section=$data['section']??null; $semester=$data['semester']??null;
$qualities=$data['qualities']??null;
$verificationMethod = strtolower(trim($data['verificationMethod'] ?? 'email'));

if (!$name||!$email||!$password||!$university||!$department||!$course||!$reason||!$image) {
  json_response(['error'=>'All required fields must be filled.'],400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { json_response(['error'=>'Invalid email address.'],400); }
if (strlen($password)<6) { json_response(['error'=>'Password must be at least 6 characters.'],400); }
if ($verificationMethod !== 'email') { json_response(['error'=>'Only email verification is available currently.'],400); }

$hashed = password_hash($password, PASSWORD_BCRYPT);

// Check email duplicate
$stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
$stmt->bind_param("s",$email); $stmt->execute();
if ($stmt->get_result()->num_rows > 0) { json_response(['error'=>'Email already exists.'],400); }
$stmt->close();

// Check rollNo duplicate
if ($rollNo) {
  $stmt = $conn->prepare("SELECT id FROM users WHERE rollNo=?");
  $stmt->bind_param("s",$rollNo); $stmt->execute();
  if ($stmt->get_result()->num_rows > 0) { json_response(['error'=>'Roll number already exists.'],400); }
  $stmt->close();
}

// Check sapId duplicate
if ($sapId) {
  $stmt = $conn->prepare("SELECT id FROM users WHERE sapId=?");
  $stmt->bind_param("s",$sapId); $stmt->execute();
  if ($stmt->get_result()->num_rows > 0) { json_response(['error'=>'SAP ID already exists.'],400); }
  $stmt->close();
}

$stmt = $conn->prepare("INSERT INTO users (name,email,password,rollNo,sapId,university,department,course,shift,section,semester,image,reason,qualities,approvalStatus) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending')");
$stmt->bind_param("ssssssssssssss",$name,$email,$hashed,$rollNo,$sapId,$university,$department,$course,$shift,$section,$semester,$image,$reason,$qualities);
if ($stmt->execute()) {
  json_response(['message'=>'User registered. Please verify your email.','userId'=>$conn->insert_id],201);
} else {
  json_response(['error'=>'Registration failed: '.$conn->error],500);
}
$stmt->close();
