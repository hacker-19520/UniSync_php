<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_response(['error'=>'Method not allowed'],405); }
$data = json_decode(file_get_contents('php://input'), true);
$email=$data['email']??''; $name=$data['name']??'';
$method = strtolower(trim($data['method'] ?? 'email'));
if (!$email) { json_response(['error'=>'Email is required.'],400); }
if ($method !== 'email') { json_response(['error'=>'Only email verification is supported right now.'],400); }
$otp = generate_otp();
$expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));
$stmt=$conn->prepare("DELETE FROM otp_codes WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute(); $stmt->close();
$stmt=$conn->prepare("INSERT INTO otp_codes (email,code,expiresAt) VALUES (?,?,?)"); $stmt->bind_param("sss",$email,$otp,$expiresAt); $stmt->execute(); $stmt->close();
send_otp_email($email,$otp,$name,'verification');
json_response(['message'=>'OTP sent.','mockOtp'=>$otp]);
