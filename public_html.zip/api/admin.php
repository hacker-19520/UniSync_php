<?php
require_once '../includes/functions.php';
require_once '../includes/auth.php';
requireAdmin();

$action = $_GET['action'] ?? '';
$userId = getCurrentUserId();

switch ($action) {
    case 'stats':
        $stats = [
            'totalUsers' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
            'verifiedUsers' => $pdo->query("SELECT COUNT(*) FROM users WHERE isVerified = 1")->fetchColumn(),
            'pendingApprovals' => $pdo->query("SELECT COUNT(*) FROM users WHERE approvalStatus = 'pending'")->fetchColumn(),
            'totalRequests' => $pdo->query("SELECT COUNT(*) FROM requests")->fetchColumn(),
            'totalMessages' => $pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn(),
            'universityBreakdown' => $pdo->query("SELECT university, COUNT(*) as count FROM users GROUP BY university ORDER BY count DESC LIMIT 10")->fetchAll(),
        ];
        apiResponse(true, $stats);
        break;

    case 'users':
        $stmt = $pdo->query("SELECT * FROM users ORDER BY createdAt DESC");
        apiResponse(true, ['users' => $stmt->fetchAll()]);
        break;

    case 'requests':
        $stmt = $pdo->query("SELECT r.*, s.name as senderName, s.email as senderEmail, rec.name as receiverName, rec.email as receiverEmail 
                             FROM requests r 
                             JOIN users s ON r.senderId = s.id 
                             JOIN users rec ON r.receiverId = rec.id 
                             ORDER BY r.createdAt DESC");
        apiResponse(true, ['requests' => $stmt->fetchAll()]);
        break;

    case 'messages':
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM messages");
        $total = $stmt->fetchColumn();
        apiResponse(true, ['totalMessages' => $total]);
        break;

    case 'approve':
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("UPDATE users SET approvalStatus = 'approved', rejectionReason = NULL WHERE id = ?")->execute([$id]);
        apiResponse(true, null, 'User approved!');
        break;

    case 'reject':
        $id = (int)($_GET['id'] ?? 0);
        $reason = sanitize($_POST['reason'] ?? '');
        if (empty($reason)) apiResponse(false, null, 'Reason required');
        $pdo->prepare("UPDATE users SET approvalStatus = 'rejected', rejectionReason = ? WHERE id = ?")->execute([$reason, $id]);
        apiResponse(true, null, 'User rejected');
        break;

    case 'verify':
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("UPDATE users SET isVerified = 1 WHERE id = ?")->execute([$id]);
        apiResponse(true, null, 'User verified');
        break;

    case 'admin':
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("UPDATE users SET isAdmin = 1 WHERE id = ?")->execute([$id]);
        apiResponse(true, null, 'User promoted to admin');
        break;

    case 'delete':
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
        apiResponse(true, null, 'User deleted');
        break;

    default:
        apiResponse(false, null, 'Invalid action');
}
?>

