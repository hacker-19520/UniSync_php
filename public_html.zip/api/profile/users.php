<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$userId = $_SESSION['user_id'];
// Return all approved users except current user and those already in a request with current user
$sql = "SELECT u.id,u.name,u.university,u.department,u.course,u.shift,u.section,u.semester,u.image,u.reason,u.qualities
        FROM users u
        WHERE u.id != ? AND u.approvalStatus='approved' AND u.isVerified=1
        AND u.id NOT IN (
          SELECT CASE WHEN senderId=? THEN receiverId ELSE senderId END
          FROM requests WHERE senderId=? OR receiverId=?
        )
        ORDER BY u.createdAt DESC";
$stmt=$conn->prepare($sql);
$stmt->bind_param("iiii",$userId,$userId,$userId,$userId); $stmt->execute();
$users=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
json_response(['users'=>$users]);
