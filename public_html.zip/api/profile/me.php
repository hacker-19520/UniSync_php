<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$userId = $_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD']==='GET') {
  $stmt=$conn->prepare("SELECT id,name,email,rollNo,sapId,university,department,course,shift,section,semester,image,reason,qualities,isVerified,isAdmin,approvalStatus FROM users WHERE id=?");
  $stmt->bind_param("i",$userId); $stmt->execute();
  $user=$stmt->get_result()->fetch_assoc(); $stmt->close();
  if (!$user) { json_response(['error'=>'User not found.'],404); }
  json_response(['user'=>$user]);
} elseif ($_SERVER['REQUEST_METHOD']==='POST'||$_SERVER['REQUEST_METHOD']==='PUT') {
  $data=json_decode(file_get_contents('php://input'),true);
  $name=$data['name']??''; $rollNo=$data['rollNo']??null; $sapId=$data['sapId']??null;
  $university=$data['university']??''; $department=$data['department']??''; $course=$data['course']??'';
  $shift=$data['shift']??null; $section=$data['section']??null; $semester=$data['semester']??null;
  $reason=$data['reason']??''; $qualities=$data['qualities']??null;
  $stmt=$conn->prepare("UPDATE users SET name=?,rollNo=?,sapId=?,university=?,department=?,course=?,shift=?,section=?,semester=?,reason=?,qualities=? WHERE id=?");
  $stmt->bind_param("sssssssssssi",$name,$rollNo,$sapId,$university,$department,$course,$shift,$section,$semester,$reason,$qualities,$userId);
  if ($stmt->execute()) { $_SESSION['user_name']=$name; json_response(['message'=>'Profile updated.']); }
  else { json_response(['error'=>'Update failed.'],500); }
  $stmt->close();
} else { json_response(['error'=>'Method not allowed'],405); }
