<?php
require_once '../includes/functions.php';
require_once '../includes/auth.php';
// PHPMailer loaded in functions.php

$action = $_GET['action'] ?? $_POST['action'] ?? '';

header('Content-Type: application/json');

switch ($action) {
    case 'register':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        
        $required = ['name', 'email', 'password', 'university', 'department', 'course', 'image', 'reason'];
        foreach ($required as $field) {
            if (empty($input[$field])) apiResponse(false, null, 'Missing required field: ' . $field);
        }

        $hashedPass = password_hash($input['password'], PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, rollNo, sapId, university, department, course, shift, section, semester, image, reason, qualities, approvalStatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $params = [$input['name'], $input['email'], $hashedPass, $input['rollNo'] ?? null, $input['sapId'] ?? null, $input['university'], $input['department'], $input['course'], $input['shift'] ?? null, $input['section'] ?? null, $input['semester'] ?? null, $input['image'], $input['reason'], $input['qualities'] ?? null];
        
        try {
            $stmt->execute($params);
            apiResponse(true, ['userId' => $pdo->lastInsertId()], 'Registered! Check email for OTP or wait for admin approval.');
        } catch (PDOException $e) {
            if ($e->errorInfo[1] == 1062) { // Duplicate entry
                apiResponse(false, null, 'Email/RollNo/SAP ID already exists');
            } else {
                apiResponse(false, null, 'Registration failed: ' . $e->getMessage());
            }
        }
        break;

    case 'send-otp':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = sanitize($input['email'] ?? '');
        $name = sanitize($input['name'] ?? '');
        
        if (empty($email)) apiResponse(false, null, 'Email required');
        
        $otp = generateOTP();
        $expires = date('Y-m-d H:i:s', time() + 600); // 10 min
        
        $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
        $stmt = $pdo->prepare("INSERT INTO otp_codes (email, code, expiresAt) VALUES (?, ?, ?)");
        $stmt->execute([$email, $otp, $expires]);
        
        $sent = sendOTPEmail($email, $otp, $name, 'verification');
        apiResponse(true, null, $sent ? 'OTP sent!' : 'OTP generated (email config needed)', ['mockOtp' => $otp]);
        break;

    case 'verify-otp':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = sanitize($input['email'] ?? '');
        $code = sanitize($input['code'] ?? '');
        
        if (empty($email) || empty($code)) apiResponse(false, null, 'Email and code required');
        
        $stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE email = ? ORDER BY createdAt DESC LIMIT 1");
        $stmt->execute([$email]);
        $otp = $stmt->fetch();
        
        if (!$otp || strtotime($otp['expiresAt']) < time() || $otp['code'] !== $code) {
            apiResponse(false, null, 'Invalid/expired OTP');
        }
        
        $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
        $pdo->prepare("UPDATE users SET isVerified = 1 WHERE email = ?")->execute([$email]);
        apiResponse(true, null, 'Email verified!');
        break;

    case 'login-request':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = sanitize($input['email'] ?? '');
        $password = $input['password'] ?? '';
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($password, $user['password'])) {
            apiResponse(false, null, 'Invalid credentials');
        }
        if (!$user['isVerified']) apiResponse(false, null, 'Verify email first');
        if ($user['approvalStatus'] !== 'approved') {
            apiResponse(false, null, $user['approvalStatus'] === 'rejected' ? 'Account rejected: ' . $user['rejectionReason'] : 'Pending admin approval');
        }
        
        $otp = generateOTP();
        $expires = date('Y-m-d H:i:s', time() + 600);
        $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
        $pdo->prepare("INSERT INTO otp_codes (email, code, expiresAt) VALUES (?, ?, ?)")->execute([$email, $otp, $expires]);
        
        sendOTPEmail($email, $otp, $user['name'], 'login');
        apiResponse(true, null, 'OTP sent!', ['mockOtp' => $otp]);
        break;

    case 'verify-login-otp':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = sanitize($input['email'] ?? '');
        $code = sanitize($input['code'] ?? '');
        
        $stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE email = ? ORDER BY createdAt DESC LIMIT 1");
        $stmt->execute([$email]);
        $otp = $stmt->fetch();
        
        if (!$otp || strtotime($otp['expiresAt']) < time() || $otp['code'] !== $code) {
            apiResponse(false, null, 'Invalid/expired OTP');
        }
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
        loginUser($user);
        apiResponse(true, ['user' => $user], 'Logged in!');
        break;

    case 'me':
        requireAuth();
        $userId = getCurrentUserId();
        $stmt = $pdo->prepare("SELECT id, name, email, rollNo, sapId, university, department, course, shift, section, semester, image, reason, qualities, isAdmin, approvalStatus, rejectionReason FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        apiResponse(true, ['user' => $user ?: null]);
        break;

    case 'logout':
        logout();
        break;

    case 'skip-verify':
        // Demo only
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = sanitize($input['email'] ?? '');
        $pdo->prepare("UPDATE users SET isVerified = 1 WHERE email = ?")->execute([$email]);
        apiResponse(true, null, 'Verified (demo)');
        break;

    default:
        apiResponse(false, null, 'Invalid action');
}
?>

