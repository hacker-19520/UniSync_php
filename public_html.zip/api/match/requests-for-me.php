<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$userId=(int)$_SESSION['user_id'];
$stmt=$conn->prepare("SELECT r.id, r.senderId, r.receiverId, r.status, r.createdAt, u.name, u.university, u.department, u.course, u.shift, u.section, u.semester, u.image, u.reason, u.qualities FROM requests r JOIN users u ON r.senderId = u.id WHERE r.receiverId=? AND r.status='pending' ORDER BY r.createdAt DESC");
$stmt->bind_param("i",$userId); $stmt->execute();
$rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
json_response(['requests'=>$rows]);
?>
