<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$requestId=(int)($_GET['id']??0); $userId=(int)$_SESSION['user_id'];
$stmt=$conn->prepare("SELECT * FROM requests WHERE id=? AND receiverId=? AND status='pending'");
$stmt->bind_param("ii",$requestId,$userId); $stmt->execute();
if ($stmt->get_result()->num_rows===0) { json_response(['error'=>'Request not found.'],404); }
$stmt->close();
$stmt=$conn->prepare("UPDATE requests SET status='rejected' WHERE id=?");
$stmt->bind_param("i",$requestId); $stmt->execute(); $stmt->close();
json_response(['message'=>'Request rejected.']);
