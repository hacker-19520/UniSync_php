<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$userId=(int)$_SESSION['user_id'];
$sql="SELECT r.id, r.senderId, r.receiverId, r.createdAt,
  CASE WHEN r.senderId=? THEN u2.id ELSE u1.id END as matchId,
  CASE WHEN r.senderId=? THEN u2.name ELSE u1.name END as matchName,
  CASE WHEN r.senderId=? THEN u2.university ELSE u1.university END as matchUniversity,
  CASE WHEN r.senderId=? THEN u2.department ELSE u1.department END as matchDepartment,
  CASE WHEN r.senderId=? THEN u2.course ELSE u1.course END as matchCourse,
  CASE WHEN r.senderId=? THEN u2.shift ELSE u1.shift END as matchShift,
  CASE WHEN r.senderId=? THEN u2.section ELSE u1.section END as matchSection,
  CASE WHEN r.senderId=? THEN u2.semester ELSE u1.semester END as matchSemester,
  CASE WHEN r.senderId=? THEN u2.image ELSE u1.image END as matchImage
  FROM requests r
  JOIN users u1 ON r.senderId=u1.id
  JOIN users u2 ON r.receiverId=u2.id
  WHERE (r.senderId=? OR r.receiverId=?) AND r.status='accepted'
  ORDER BY r.createdAt DESC";
$stmt=$conn->prepare($sql);
$stmt->bind_param("iiiiiiiiiii",$userId,$userId,$userId,$userId,$userId,$userId,$userId,$userId,$userId,$userId,$userId);
$stmt->execute(); $rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
json_response(['matches'=>$rows]);
