<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
$userId=(int)$_SESSION['user_id'];
$stmt=$conn->prepare("SELECT r.*,u.name,u.university,u.department,u.image FROM requests r JOIN users u ON r.receiverId=u.id WHERE r.senderId=? ORDER BY r.createdAt DESC");
$stmt->bind_param("i",$userId); $stmt->execute();
$rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
json_response(['requests'=>$rows]);
