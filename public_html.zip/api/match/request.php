<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_logged_in()) { json_response(['error'=>'Unauthorized'],401); }
if ($_SERVER['REQUEST_METHOD']!=='POST') { json_response(['error'=>'Method not allowed'],405); }
$data=json_decode(file_get_contents('php://input'),true);
$receiverId=(int)($data['receiverId']??0); $senderId=(int)$_SESSION['user_id'];
if (!$receiverId) { json_response(['error'=>'Receiver ID required.'],400); }
if ($receiverId===$senderId) { json_response(['error'=>'Cannot send request to yourself.'],400); }
$stmt=$conn->prepare("SELECT id FROM requests WHERE (senderId=? AND receiverId=?) OR (senderId=? AND receiverId=?)");
$stmt->bind_param("iiii",$senderId,$receiverId,$receiverId,$senderId); $stmt->execute();
if ($stmt->get_result()->num_rows>0) { json_response(['error'=>'Request already exists.'],400); }
$stmt->close();
$stmt=$conn->prepare("INSERT INTO requests (senderId,receiverId,status) VALUES (?,?,'pending')");
$stmt->bind_param("ii",$senderId,$receiverId);
if ($stmt->execute()) { json_response(['message'=>'Request sent.','requestId'=>$conn->insert_id],201); }
else { json_response(['error'=>'Failed to send request.'],500); }
$stmt->close();
