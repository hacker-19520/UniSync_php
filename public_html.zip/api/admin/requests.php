<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$rows=$conn->query("
  SELECT
    r.*,
    s.name as senderName,
    s.email as senderEmail,
    s.image as senderImage,
    s.university as senderUniversity,
    s.department as senderDepartment,
    s.course as senderCourse,
    s.rollNo as senderRollNo,
    s.shift as senderShift,
    s.section as senderSection,
    s.semester as senderSemester,
    rec.name as receiverName,
    rec.email as receiverEmail,
    rec.image as receiverImage,
    rec.university as receiverUniversity,
    rec.department as receiverDepartment,
    rec.course as receiverCourse,
    rec.rollNo as receiverRollNo,
    rec.shift as receiverShift,
    rec.section as receiverSection,
    rec.semester as receiverSemester
  FROM requests r
  JOIN users s ON r.senderId=s.id
  JOIN users rec ON r.receiverId=rec.id
  ORDER BY r.createdAt DESC
")->fetch_all(MYSQLI_ASSOC);
json_response(['requests'=>$rows]);
