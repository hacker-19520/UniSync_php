<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$data=json_decode(file_get_contents('php://input'),true);
$id=(int)($_GET['id']??0); $reason=trim($data['reason']??'');
if (!$reason) { json_response(['error'=>'Rejection reason required.'],400); }
$stmt=$conn->prepare("UPDATE users SET approvalStatus='rejected',rejectionReason=? WHERE id=?");
$stmt->bind_param("si",$reason,$id); $stmt->execute(); $stmt->close();
json_response(['message'=>"User $id rejected."]);
