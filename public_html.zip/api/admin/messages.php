<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$requestId=(int)($_GET['request_id']??0);
if ($requestId) {
  $stmt=$conn->prepare("
    SELECT m.*,
           u.name as senderName,
           u.email as senderEmail,
           u.image as senderImage
    FROM messages m
    JOIN users u ON m.senderId=u.id
    WHERE m.requestId=?
    ORDER BY m.createdAt ASC
  ");
  $stmt->bind_param("i",$requestId); $stmt->execute();
  $msgs=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
  json_response(['messages'=>$msgs]);
} else {
  $rows=$conn->query("
    SELECT
      m.requestId,
      COUNT(*) as messageCount,
      MAX(m.createdAt) as lastMessageAt,
      SUBSTRING_INDEX(GROUP_CONCAT(m.content ORDER BY m.createdAt DESC SEPARATOR '|||'), '|||', 1) as lastMessage,
      s.name as senderName,
      s.email as senderEmail,
      s.image as senderImage,
      r.name as receiverName,
      r.email as receiverEmail,
      r.image as receiverImage
    FROM messages m
    JOIN requests req ON m.requestId=req.id
    LEFT JOIN users s ON req.senderId=s.id
    LEFT JOIN users r ON req.receiverId=r.id
    GROUP BY m.requestId,req.senderId,req.receiverId,s.name,s.email,s.image,r.name,r.email,r.image
    ORDER BY lastMessageAt DESC
    LIMIT 200
  ")->fetch_all(MYSQLI_ASSOC);
  json_response(['conversations'=>$rows]);
}
