<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$totalUsers=$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$verifiedUsers=$conn->query("SELECT COUNT(*) c FROM users WHERE isVerified=1")->fetch_assoc()['c'];
$pendingApprovals=$conn->query("SELECT COUNT(*) c FROM users WHERE approvalStatus='pending'")->fetch_assoc()['c'];
$totalRequests=$conn->query("SELECT COUNT(*) c FROM requests")->fetch_assoc()['c'];
$totalMessages=$conn->query("SELECT COUNT(*) c FROM messages")->fetch_assoc()['c'];
$unis=$conn->query("SELECT university,COUNT(*) as count FROM users GROUP BY university ORDER BY count DESC")->fetch_all(MYSQLI_ASSOC);
$depts=$conn->query("SELECT department,COUNT(*) as count FROM users GROUP BY department ORDER BY count DESC")->fetch_all(MYSQLI_ASSOC);
json_response(compact('totalUsers','verifiedUsers','pendingApprovals','totalRequests','totalMessages','unis','depts'));
