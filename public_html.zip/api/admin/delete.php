<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$id=(int)($_GET['id']??0);
$stmt=$conn->prepare("DELETE FROM users WHERE id=?"); $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
json_response(['message'=>"User $id deleted."]);
