<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
header('Content-Type: application/json');
if (!is_admin()) { json_response(['error'=>'Admin only'],403); }
$users=$conn->query("SELECT id,name,email,rollNo,sapId,university,department,course,shift,section,semester,image,reason,qualities,isVerified,isAdmin,approvalStatus,rejectionReason,createdAt FROM users ORDER BY createdAt DESC")->fetch_all(MYSQLI_ASSOC);
json_response(['users'=>$users]);
