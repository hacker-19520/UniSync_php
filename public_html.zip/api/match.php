<?php
require_once '../includes/functions.php';
require_once '../includes/auth.php';
requireAuth();

$action = $_GET['action'] ?? '';
$userId = getCurrentUserId();

switch ($action) {
    case 'request':
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $receiverId = (int)($input['receiverId'] ?? 0);
        
        if (!$receiverId || $receiverId == $userId) apiResponse(false, null, 'Invalid receiver');
        
        // Check existing
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE (senderId = ? AND receiverId = ?) OR (senderId = ? AND receiverId = ?)");
        $stmt->execute([$userId, $receiverId, $receiverId, $userId]);
        if ($stmt->rowCount()) apiResponse(false, null, 'Request already exists');
        
        $stmt = $pdo->prepare("INSERT INTO requests (senderId, receiverId) VALUES (?, ?)");
        $stmt->execute([$userId, $receiverId]);
        apiResponse(true, ['requestId' => $pdo->lastInsertId()], 'Request sent!');
        break;

    case 'accept':
        $requestId = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND receiverId = ? AND status = 'pending'");
        $stmt->execute([$requestId, $userId]);
        if (!$stmt->fetch()) apiResponse(false, null, 'Request not found');
        
        $pdo->prepare("UPDATE requests SET status = 'accepted' WHERE id = ?")->execute([$requestId]);
        apiResponse(true, null, 'Request accepted!');
        break;

    case 'reject':
        $requestId = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND receiverId = ? AND status = 'pending'");
        $stmt->execute([$requestId, $userId]);
        if (!$stmt->fetch()) apiResponse(false, null, 'Request not found');
        
        $pdo->prepare("UPDATE requests SET status = 'rejected' WHERE id = ?")->execute([$requestId]);
        apiResponse(true, null, 'Request rejected');
        break;

    case 'my-requests':
        $stmt = $pdo->prepare("SELECT r.*, u.name, u.university, u.department, u.image FROM requests r JOIN users u ON r.receiverId = u.id WHERE r.senderId = ? ORDER BY r.createdAt DESC");
        $stmt->execute([$userId]);
        apiResponse(true, ['requests' => $stmt->fetchAll()]);
        break;

    case 'requests-for-me':
        $stmt = $pdo->prepare("SELECT r.*, u.name, u.university, u.department, u.image FROM requests r JOIN users u ON r.senderId = u.id WHERE r.receiverId = ? AND r.status = 'pending' ORDER BY r.createdAt DESC");
        $stmt->execute([$userId]);
        apiResponse(true, ['requests' => $stmt->fetchAll()]);
        break;

    case 'my-matches':
        $stmt = $pdo->prepare("SELECT r.*, 
            CASE WHEN r.senderId = ? THEN u2.name ELSE u1.name END as matchName,
            CASE WHEN r.senderId = ? THEN u2.image ELSE u1.image END as matchImage
            FROM requests r 
            JOIN users u1 ON r.senderId = u1.id 
            JOIN users u2 ON r.receiverId = u2.id 
            WHERE (r.senderId = ? OR r.receiverId = ?) AND r.status = 'accepted' 
            ORDER BY r.createdAt DESC");
        $stmt->execute([$userId, $userId, $userId, $userId]);
        apiResponse(true, ['matches' => $stmt->fetchAll()]);
        break;

    default:
        apiResponse(false, null, 'Invalid action');
}
?>

