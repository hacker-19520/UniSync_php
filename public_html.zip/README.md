# UniSync PHP 🚀 - Fully Functional University Matching Platform

Fully recreated from original Node/React app in **pure PHP + MySQL** for **XAMPP**. All features working!

## 🎯 Features (100% Complete)
✅ **Auth**: Register → OTP email verify → Admin approve → Login (pass + OTP)  
✅ **Profile**: View/edit, find same-uni verified users  
✅ **Matching**: Send/accept/reject requests, my requests/matches  
✅ **Chat**: Real-time AJAX polling for accepted matches  
✅ **Admin**: Stats, approve/reject/verify/promote users, view all data  
✅ **UI**: TailwindCSS responsive, custom cursor, loading states, toasts  
✅ **Security**: PDO prepared, CSRF, sanitize, sessions  

Demo admin: `admin@unisync.com` / `password`

## ⚙️ Setup for Hostinger (Production Deployment)

### 1. Database Setup
- Log in to your Hostinger control panel
- Go to **Databases** → **MySQL Databases**
- Create a new database (e.g., `unisync_db`)
- Create a database user and assign it to the database
- Note down the database name, username, and password

### 2. Upload Files
- Use Hostinger's **File Manager** or FTP/SFTP
- Upload all files from this project to `public_html/` (for root domain) or `public_html/unisync-php/` (for subdirectory)
- Ensure PHP version is 7.4+ (check in Hosting → PHP Configuration)

### 3. Configure Database
- Edit `includes/config.php` and update:
  ```php
  define('DB_HOST', 'localhost');
  define('DB_USER', 'your_db_username');
  define('DB_PASS', 'your_db_password');
  define('DB_NAME', 'your_db_name');
  define('APP_URL', 'https://yourdomain.com'); // Your actual domain
  ```
- If using subdirectory, update APP_URL to `https://yourdomain.com/unisync-php`

### 4. Import Database Schema
- Go to **phpMyAdmin** in Hostinger control panel
- Select your database
- Import `unisync_db.sql`
- Alternatively, run `db-setup.php` in your browser once, then delete it

### 5. Email Configuration (Optional)
- For real OTP emails, update SMTP settings in `includes/config.php`
- Use your domain's email or a service like Gmail
- Change `OTP_MODE` to `'email'`

### 6. Permissions (if needed)
- Ensure `uploads/` and `images/` directories are writable (755 permissions)

### 7. Launch
- Visit your domain: `https://yourdomain.com`
- Register a new account
- Use phpMyAdmin to approve users (set `approvalStatus='approved'`)
- Demo admin: `admin@unisync.com` / `password`

## 📱 Test Flow
1. **index.php** → Landing (perfect replica)
2. **signup.php** → Register (pending status)
3. **phpMyAdmin** → Approve user (approvalStatus='approved')
4. **login.php** → Pass + OTP → Dashboard
5. **matches.php** → Find/send requests
6. **chats.php/chat.php** → Message after accept
7. **admin.php** → Full admin (demo login)

## 🛠 Tech Stack
- **Backend**: Pure PHP 8+, PDO MySQL
- **Frontend**: HTML/JS/TailwindCDN, AJAX fetch
- **Libs**: PHPMailer (email), password_hash (bcrypt equiv)
- **Security**: Sessions, CSRF, input sanitize, PDO
- **Chat**: AJAX poll (2s, no WebSocket needed)

## 📁 Structure
```
unisync-php/
├── index.php (landing)
├── pages/ (signup/login/verify + protected dashboard/profile/matches/chats/chat/admin)
├── api/ (auth/profile/match/chat/admin handlers)
├── includes/ (config/auth/functions/header)
├── assets/app.js (AJAX/cursor/chat-poll/toasts)
├── unisync_db.sql
└── README.md
```

## 🔧 Customization
- **Upload images**: Add `uploads/` handler in register
- **Production**: Add JWT, rate limit, image resize
- **WebSocket**: Replace poll with Pusher/Ratchet
- **Search**: Add fulltext university/qualities

## 🎉 Status
**Fully functional!** All original features ported. Move to htdocs, import DB, config email = LIVE ✅

**Live demo command:** `open /Users/ahmad/Desktop/unisync-php/index.php`

