<?php
// Copy to .env.php and edit!
return [
    'SMTP_HOST' => 'smtp.gmail.com',
    'SMTP_PORT' => 587,
    'SMTP_USER' => 'your-gmail@gmail.com', // Your Gmail
    'SMTP_PASS' => 'your-app-password',    // Gmail App Password (not regular pass!)
    'SMTP_FROM' => 'UniSync <noreply@unisync.com>'
];
?>
</xai:function_call >

<xai:function_call name="create_file">
<parameter name="absolute_path">/Users/ahmad/Desktop/includes/auth.php
