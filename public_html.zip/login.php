<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$pageTitle = 'Login';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - UniSync</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="auth-wrap animate-fade-in">
  <div class="auth-card animate-scale-in">
    <div class="auth-icon">
      <svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="#2563eb"><path stroke-linecap="round" stroke-linejoin="round" d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline stroke-linecap="round" stroke-linejoin="round" points="10 17 15 12 10 7"/><line stroke-linecap="round" stroke-linejoin="round" x1="15" y1="12" x2="3" y2="12"/></svg>
    </div>
    <h1 class="auth-title">Welcome Back</h1>
    <p class="auth-sub">Login to your UniSync account</p>

    <div id="error-box" class="alert alert-error" style="display:none;"></div>
    <div id="pending-box" class="alert alert-warning" style="display:none;">
      <svg style="width:20px;height:20px;flex-shrink:0;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <div><strong>Waiting for Approval</strong><br><span style="font-size:.85rem;">Your account is under review. Our team will respond within 24 hours.</span></div>
    </div>
    <div id="rejected-box" class="alert alert-error" style="display:none;">
      <div>
        <strong>Account Rejected</strong>
        <div id="rejection-reason" style="background:#fee2e2;border-left:4px solid #dc2626;padding:10px;border-radius:6px;margin:8px 0;font-size:.85rem;"></div>
        <p style="font-size:.85rem;">Please correct the issues and <a href="signup.php" style="color:#dc2626;font-weight:700;">sign up again</a>.</p>
      </div>
    </div>

    <!-- STEP 1 -->
    <form id="step1-form">
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="input-icon-wrap">
          <svg class="icon" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 0 0 2.22 0L21 8M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"/></svg>
          <input type="email" id="email" class="input-field" placeholder="john@university.edu" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-icon-wrap">
          <svg class="icon" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path stroke-linecap="round" stroke-linejoin="round" d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input type="password" id="password" class="input-field" placeholder="••••••••" required>
        </div>
      </div>
      <button type="submit" id="step1-btn" class="btn btn-primary btn-block" style="padding:12px;">
        Continue <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
      </button>
    </form>

    <!-- STEP 2 -->
    <form id="step2-form" style="display:none;">
      <div class="alert alert-info" style="flex-direction:column;text-align:center;">
        <svg style="width:32px;height:32px;color:#2563eb;margin:0 auto 8px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0z"/></svg>
        <strong>Check your email!</strong>
        <span style="font-size:.85rem;" id="otp-email-hint"></span>
      </div>
      <div id="mock-otp-box" class="alert alert-warning" style="display:none;text-align:center;">
        <div><span style="font-weight:700;">Demo Mode — Your OTP: </span><span id="mock-otp" style="font-size:1.4rem;font-weight:800;letter-spacing:.2em;color:#92400e;"></span></div>
      </div>
      <div class="form-group">
        <label class="form-label">Enter OTP</label>
        <input type="text" id="otp" class="input-field otp-input" maxlength="6" placeholder="______" required>
      </div>
      <button type="submit" id="step2-btn" class="btn btn-primary btn-block" style="padding:12px;">
        Verify &amp; Login
      </button>
      <button type="button" onclick="resetStep()" class="btn btn-ghost btn-block" style="margin-top:8px;">← Back to login</button>
    </form>

    <p style="text-align:center;margin-top:20px;color:#6b7280;font-size:.9rem;">
      Don't have an account? <a href="signup.php" style="color:#2563eb;font-weight:600;">Sign up</a>
    </p>
    <p style="text-align:center;margin-top:8px;color:#6b7280;font-size:.9rem;">
      <a href="index.php" style="color:#4b5563;font-weight:600;">← Back to Home</a>
    </p>
  </div>
</div>
<script src="assets/app.js"></script>
<script>
let emailVal='';
document.getElementById('step1-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAllAlerts();
  emailVal = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const btn = document.getElementById('step1-btn');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Logging in...';
  const {ok,data} = await api('api/auth/login-request.php','POST',{email:emailVal,password});
  btn.disabled=false; btn.innerHTML='Continue <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>';
  if (!ok) {
    if (data.approvalStatus==='pending') { document.getElementById('pending-box').style.display='flex'; return; }
    if (data.approvalStatus==='rejected') {
      document.getElementById('rejected-box').style.display='flex';
      document.getElementById('rejection-reason').textContent = 'Reason: ' + (data.rejectionReason||'No reason provided'); return;
    }
    document.getElementById('error-box').textContent = data.error||'Login failed'; document.getElementById('error-box').style.display='flex';
    document.getElementById('error-box').classList.add('animate-shake'); return;
  }
  document.getElementById('step1-form').style.display='none';
  document.getElementById('step2-form').style.display='block';
  document.getElementById('otp-email-hint').textContent = 'We sent a 6-digit code to ' + emailVal;
  if (data.mockOtp) { document.getElementById('mock-otp-box').style.display='flex'; document.getElementById('mock-otp').textContent=data.mockOtp; }
});

document.getElementById('step2-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAllAlerts();
  const otp = document.getElementById('otp').value;
  const btn = document.getElementById('step2-btn');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Verifying...';
  const {ok,data} = await api('api/auth/verify-login-otp.php','POST',{email:emailVal,code:otp});
  btn.disabled=false; btn.textContent='Verify & Login';
  if (!ok) { document.getElementById('error-box').textContent=data.error||'Verification failed'; document.getElementById('error-box').style.display='flex'; return; }
  window.location.href='dashboard.php';
});

function hideAllAlerts() {
  ['error-box','pending-box','rejected-box'].forEach(id => { document.getElementById(id).style.display='none'; });
}
function resetStep() {
  document.getElementById('step1-form').style.display='block';
  document.getElementById('step2-form').style.display='none';
  hideAllAlerts();
}
</script>
</body>
</html>
