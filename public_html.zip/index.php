<?php
$pageTitle = 'UniSync - Find Your University Duo';
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) { header('Location: /dashboard.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="UniSync - Find Your University Duo. Connect with students who share your qualities and ambitions.">
  <title>UniSync - Find Your University Duo</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="assets/style.css">
</head>
<body style="margin:0;padding:0;">

<!-- HERO -->
<section class="hero">
  <div style="max-width:800px;margin:0 auto;">
    <div style="width:80px;height:80px;background:rgba(255,255,255,.2);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 24px;backdrop-filter:blur(10px);">
      <svg style="width:44px;height:44px;color:white;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    </div>
    <h1>Find Your Perfect <span style="color:#bfdbfe;">University Duo</span></h1>
    <p>Connect with students who share your qualities, niche, and ambitions. Whether you need a study partner, a friend, or someone who gets you — UniSync brings you together.</p>
    <div class="hero-btns">
      <a href="signup.php" class="btn-hero-white" style="display:inline-flex;align-items:center;gap:8px;">
        Get Started
        <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
      </a>
      <a href="login.php" class="btn-hero-outline">Already a Member? Login</a>
    </div>
  </div>
</section>

<!-- FEATURES -->
<section style="padding:72px 24px;background:white;">
  <div style="max-width:1100px;margin:0 auto;">
    <h2 style="text-align:center;font-size:1.9rem;font-weight:800;margin-bottom:48px;">Why Choose UniSync?</h2>
    <div class="card-grid card-grid-4">
      <?php
      $features = [
        ['color'=>'#dbeafe','icon-color'=>'#2563eb','title'=>'Smart Matching','desc'=>'Find students based on qualities, niche, and study habits that match yours.','icon'=>'<path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/>'],
        ['color'=>'#dcfce7','icon-color'=>'#16a34a','title'=>'Verified Community','desc'=>'All members are verified via email OTP to ensure a safe environment.','icon'=>'<path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0 1 12 2.944a11.955 11.955 0 0 1-8.618 3.04A12.02 12.02 0 0 0 3 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>'],
        ['color'=>'#f3e8ff','icon-color'=>'#9333ea','title'=>'In-App Chat','desc'=>'Connect and chat with your matches directly within the platform.','icon'=>'<path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>'],
        ['color'=>'#ffe4e6','icon-color'=>'#e11d48','title'=>'Meaningful Connections','desc'=>'Build real relationships with students who share your goals.','icon'=>'<path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 0 0 0 6.364L12 20.364l7.682-7.682a4.5 4.5 0 0 0-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 0 0-6.364 0z"/>'],
      ];
      foreach ($features as $f): ?>
      <div class="card" style="text-align:center;">
        <div class="feature-icon" style="background:<?= $f['color'] ?>;">
          <svg style="width:28px;height:28px;color:<?= $f['icon-color'] ?>;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><?= $f['icon'] ?></svg>
        </div>
        <h3 style="font-size:1rem;font-weight:700;margin-bottom:8px;"><?= $f['title'] ?></h3>
        <p style="color:#6b7280;font-size:.88rem;"><?= $f['desc'] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section style="padding:72px 24px;background:#f9fafb;">
  <div style="max-width:900px;margin:0 auto;">
    <h2 style="text-align:center;font-size:1.9rem;font-weight:800;margin-bottom:48px;">How It Works</h2>
    <div class="card-grid card-grid-3">
      <?php $steps=[['Create Your Profile','Sign up with your university details, add your photo, and share your qualities.'],['Find Your Match','Browse students and send connection requests to those who interest you.'],['Start Connecting','Once accepted, chat and build your university duo relationship!']];
      foreach ($steps as $i=>$s): ?>
      <div style="text-align:center;">
        <div class="step-number"><?= $i+1 ?></div>
        <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:8px;"><?= $s[0] ?></h3>
        <p style="color:#6b7280;font-size:.9rem;"><?= $s[1] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section style="padding:72px 24px;background:linear-gradient(135deg,#2563eb,#4338ca);text-align:center;color:white;">
  <div style="max-width:600px;margin:0 auto;">
    <h2 style="font-size:2rem;font-weight:800;margin-bottom:12px;">Ready to Find Your Duo?</h2>
    <p style="color:rgba(255,255,255,.85);font-size:1.1rem;margin-bottom:28px;">Join thousands of students already connecting on UniSync.</p>
    <a href="signup.php" class="btn-hero-white" style="display:inline-flex;align-items:center;gap:8px;font-size:1rem;">
      Join UniSync Now
      <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
    </a>
  </div>
</section>

<!-- DEVELOPERS -->
<!-- DEVELOPERS -->
<section style="padding:72px 24px;background:#f3f4f6;">
  <div style="max-width:1000px;margin:0 auto;">
    <div style="text-align:center;margin-bottom:40px;">
      <span style="display:inline-flex;align-items:center;gap:6px;background:#dbeafe;color:#1e40af;padding:6px 16px;border-radius:999px;font-size:.8rem;font-weight:600;margin-bottom:12px;">
        <svg style="width:14px;height:14px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
        Meet the Project Owners
      </span>
      <h2 style="font-size:1.9rem;font-weight:800;">Built with Passion</h2>
    </div>
    <div class="card-grid card-grid-2">
      <?php
      $devs = [
        ['name' => 'Sohaib Jan', 'phone' => '0334-6932860', 'image' => 'assets/sohaibjan.jpeg'],
        ['name' => 'Ahmad Bilal', 'phone' => '0328-8311026', 'image' => 'assets/ahmadbilal.jpeg']
      ];
      foreach ($devs as $d): ?>
      <div class="card dev-card-shell" style="padding:0;overflow:hidden;">
        <div class="dev-card-inner" style="display:flex;flex-direction:row;flex-wrap:wrap;">
          <div class="dev-card-side" style="width:160px;min-width:140px;flex-shrink:0;background:linear-gradient(135deg,#2563eb,#4338ca);padding:24px;display:flex;align-items:center;justify-content:center;">
            <div style="text-align:center;">
              <img src="<?= htmlspecialchars($d['image']) ?>" alt="<?= htmlspecialchars($d['name']) ?>" class="dev-image" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
              <div style="display:none;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.2);align-items:center;justify-content:center;margin:0 auto;font-size:1.8rem;font-weight:800;color:white;"><?= strtoupper(substr($d['name'],0,1)) ?></div>
              <p style="color:white;font-weight:700;margin-top:10px;font-size:.9rem;"><?= htmlspecialchars($d['name']) ?></p>
              <p style="color:rgba(255,255,255,.7);font-size:.75rem;">Project Owner</p>
            </div>
          </div>
          <div class="dev-card-content" style="flex:1;min-width:200px;padding:20px;display:flex;flex-direction:column;justify-content:center;gap:8px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="background:#dbeafe;padding:8px;border-radius:8px;flex-shrink:0;"><svg style="width:16px;height:16px;color:#2563eb;display:block;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div>
              <div style="min-width:0;"><p style="font-size:.7rem;color:#9ca3af;font-weight:600;text-transform:uppercase;margin:0;">University</p><p style="font-size:.9rem;font-weight:600;margin:0;word-break:break-word;">Emerson University, Multan</p></div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="background:#dcfce7;padding:8px;border-radius:8px;flex-shrink:0;"><svg style="width:16px;height:16px;color:#16a34a;display:block;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg></div>
              <div style="min-width:0;"><p style="font-size:.7rem;color:#9ca3af;font-weight:600;text-transform:uppercase;margin:0;">Course</p><p style="font-size:.9rem;font-weight:600;margin:0;word-break:break-word;">Software Engineering</p></div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="background:#f3e8ff;padding:8px;border-radius:8px;flex-shrink:0;"><svg style="width:16px;height:16px;color:#9333ea;display:block;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.15 12 19.79 19.79 0 0 1 1.07 3.38 2 2 0 0 1 3.04 1.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21 16.92z"/></svg></div>
              <div style="min-width:0;"><p style="font-size:.7rem;color:#9ca3af;font-weight:600;text-transform:uppercase;margin:0;">Contact</p><p style="font-size:.9rem;font-weight:600;margin:0;word-break:break-word;"><?= htmlspecialchars($d['phone']) ?></p></div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<footer style="background:#111827;color:#9ca3af;padding:28px 24px;text-align:center;font-size:.88rem;">
  <p>© 2024 UniSync. All rights reserved. Find Your University Duo.</p>
</footer>

<script src="assets/app.js"></script>
</body>
</html>
