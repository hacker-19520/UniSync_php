// ============================================================
 // UniSync App JS — chat polling, tabs, image preview, helpers (Hostinger ROOT ready)
 // All /unisync-php/ paths removed for root deployment
 // ============================================================

// SVG icons
const ICONS = {
  users: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path stroke-linecap="round" stroke-linejoin="round" d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
  send: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,
  check: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>`,
  x: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
};

// BASE PATH (works for root and subfolder deployments)
const BASE_PATH = (() => {
  const scriptEl =
    document.currentScript ||
    Array.from(document.scripts).find((s) => s.src && /assets\/app\.js/i.test(s.src));

  if (scriptEl?.src) {
    try {
      const scriptUrl = new URL(scriptEl.src, window.location.origin);
      return scriptUrl.pathname.replace(/assets\/app\.js(?:\?.*)?$/i, '');
    } catch (_) {}
  }

  const path = window.location.pathname;
  return path.slice(0, path.lastIndexOf('/') + 1);
})();

// ---- IMAGE PREVIEW ----
function setupImagePreview(inputId, previewWrapperId) {
  const input = document.getElementById(inputId);
  const wrap  = document.getElementById(previewWrapperId);
  const previewArea = wrap ? wrap.querySelector('#upload-content') : null;
  const imageData = document.getElementById('image_data');
  if (!input || !wrap || !previewArea || !imageData) return;

  input.addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { alert('Image must be under 5MB'); return; }
    const reader = new FileReader();
    reader.onload = (e) => {
      previewArea.innerHTML = `<img src="${e.target.result}" alt="Preview" style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:4px solid #86efac;display:block;margin:0 auto 8px;">
        <p style="color:#15803d;font-size:.85rem;font-weight:600;">✓ Image uploaded — click to change</p>`;
      wrap.classList.remove('required');
      wrap.classList.add('has-image');
      imageData.value = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// ---- DEPARTMENT → COURSE ----
const DEPT_COURSES = {
  'Computing and Emerging Technologies': ['CS','SE','AI','DS','Cyber Security','IT'],
  'Business Administration': ['BBA','MBA','BS Accounting','BS Finance'],
  'Engineering': ['Mechanical','Electrical','Civil','Chemical'],
  'Natural Sciences': ['Physics','Chemistry','Biology','Mathematics'],
  'Social Sciences': ['Psychology','Sociology','Political Science','Economics'],
  'Humanities': ['English','History','Philosophy','Urdu'],
  'Health Sciences': ['Medicine','Nursing','Pharmacy','DPT'],
  'Law': ['LLB'],
  'Education': ['B.Ed','M.Ed'],
};
function setupDeptCourse(deptId, courseId) {
  const dept = document.getElementById(deptId);
  const course = document.getElementById(courseId);
  if (!dept || !course) return;
  dept.addEventListener('change', () => {
    const courses = DEPT_COURSES[dept.value] || [];
    course.innerHTML = `<option value="">${dept.value ? 'Select Course' : 'Select Department First'}</option>`;
    courses.forEach(c => { const o = document.createElement('option'); o.value = c; o.textContent = c; course.appendChild(o); });
    course.disabled = !dept.value;
  });
}

// AJAX helper (root paths)
async function api(endpoint, method = 'GET', body = null) {
  const url = endpoint.startsWith('http')
    ? endpoint
    : `${BASE_PATH}${endpoint}`.replace(/([^:]\/)\/+/g, '$1');
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const text = await res.text();
  let data = {};
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (_) {
      data = { error: text };
    }
  }
  return { ok: res.ok, status: res.status, data };
}

// CHAT POLLING (root)
let chatPollInterval = null;
let lastMessageId = 0;

function startChatPolling(requestId, currentUserId, onNewMessages) {
  stopChatPolling();
  chatPollInterval = setInterval(async () => {
    const { ok, data } = await api(`api/messages/get.php?request_id=${requestId}&after=${lastMessageId}`);
    if (ok && data.messages && data.messages.length > 0) {
      lastMessageId = data.messages[data.messages.length - 1].id;
      onNewMessages(data.messages, currentUserId);
    }
  }, 3000);
}

function stopChatPolling() {
  if (chatPollInterval) { clearInterval(chatPollInterval); chatPollInterval = null; }
}

function renderMessage(msg, currentUserId) {
  const isMe = parseInt(msg.senderId) === parseInt(currentUserId);
  const time = new Date(msg.createdAt).toLocaleTimeString('en-US', {hour12: false, hour: '2-digit', minute: '2-digit'});
  const avatarHtml = !isMe && msg.senderimage ? `<img src="${msg.senderimage}" alt="" class="msg-avatar">` : '';
  const nameHtml = !isMe ? `<p class="msg-name">${escHtml(msg.sendername || 'User')}</p>` : '';
  return `<div class="msg ${isMe ? 'mine' : 'theirs'}">
    ${avatarHtml}
    <div>
      ${nameHtml}
      <div class="msg-bubble">${escHtml(msg.content)}<span class="msg-time">${time}</span></div>
    </div>
  </div>`;
}

function escHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

function scrollChatBottom(containerId) {
  const el = document.getElementById(containerId);
  if (el) el.scrollTop = el.scrollHeight;
}

// TABS
function setupTabs(tabsWrapperId, contentWrapperId, loadFn) {
  const tabsWrap = document.getElementById(tabsWrapperId);
  if (!tabsWrap) return;
  tabsWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tab]');
    if (!btn) return;
    tabsWrap.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadFn(btn.dataset.tab);
  });
}

// TOAST
function showToast(msg, type = 'success') {
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText = `position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:.88rem;font-weight:600;z-index:9999;animation:slideUp .3s ease;${type==='success'?'background:#16a34a;color:white;':'background:#dc2626;color:white;'}`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// SIDEBAR MOBILE
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('main-sidebar');
  if (toggle && sidebar) {
    toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }
  // Login forms auto-setup
  const loginForms = document.querySelectorAll('[id*=\"step1-form\"]');
  loginForms.forEach(form => form.addEventListener('submit', handleLoginStep1));
});

// Login handlers (global)
let currentEmail = '';
async function handleLoginStep1(e) {
  e.preventDefault();
  const form = e.target;
  const email = form.querySelector('#email').value;
  const password = form.querySelector('#password').value;
  const btn = form.querySelector('button[type=\"submit\"]');
  const originalText = btn.innerHTML;
  
  setLoading(btn, true, originalText);
  const {ok, data} = await api('api/auth/login-request.php', 'POST', {email, password});
  
  setLoading(btn, false, originalText);
  
  if (!ok) {
    showToast(data.error || 'Login failed', 'error');
    return;
  }
  
  currentEmail = email;
  // Switch to OTP step
  document.getElementById('step1-form')?.remove();
  if (data.mockOtp) {
    showToast(`Your OTP: ${data.mockOtp}`, 'success');
  }
}
