<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$email = htmlspecialchars($_GET['email'] ?? '');
$name  = htmlspecialchars($_GET['name'] ?? '');
$method = htmlspecialchars($_GET['method'] ?? 'email');
$initialOtp = htmlspecialchars($_GET['otp'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Verify Email - UniSync</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="auth-wrap animate-fade-in">
  <div class="auth-card animate-scale-in">
    <div class="auth-icon"><svg fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="#2563eb"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 0 0 2.22 0L21 8M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"/></svg></div>
    <h1 class="auth-title">Verify Your Email</h1>
    <p class="auth-sub">Verification method: <strong><?= ucfirst($method) ?></strong><br>We sent a 6-digit code to <strong><?= $email ?></strong></p>
    <div id="mock-box" class="alert alert-warning" style="display:<?= $initialOtp ? 'flex' : 'none' ?>;text-align:center;flex-direction:column;">
      <strong>Verification Code:</strong>
      <span id="mock-otp" style="font-size:1.8rem;font-weight:800;letter-spacing:.3em;color:#92400e;"></span>
    </div>
    <div id="error-box" class="alert alert-error" style="display:none;"></div>
    <div id="success-box" class="alert alert-success" style="display:none;"></div>
    <form id="verify-form">
      <input type="hidden" value="<?= $email ?>">
      <div class="form-group"><label class="form-label">Enter OTP</label>
        <input type="text" id="otp" class="input-field otp-input" maxlength="6" placeholder="______" required>
      </div>
      <button type="submit" id="verify-btn" class="btn btn-primary btn-block" style="padding:12px;">Verify Email</button>
    </form>
    <div style="margin-top:14px;text-align:center;">
      <button id="resend-btn" onclick="resendOtp()" class="btn btn-ghost" style="font-size:.85rem;">Resend OTP</button>
    </div>
    <p style="text-align:center;margin-top:16px;color:#6b7280;font-size:.85rem;">
      <a href="login.php" style="color:#2563eb;">← Back to Login</a> •
      <a href="index.php" style="color:#4b5563;">Home</a>
    </p>
  </div>
</div>
<script src="assets/app.js"></script>
<script>
const EMAIL='<?= addslashes($email) ?>', NAME='<?= addslashes($name) ?>';
const INITIAL_OTP='<?= addslashes($initialOtp) ?>';

if (INITIAL_OTP) {
  document.getElementById('mock-otp').textContent = INITIAL_OTP;
}

async function resendOtp() {
  document.getElementById('mock-box').style.display='none';
  const {ok,data} = await api('api/auth/send-otp.php','POST',{email:EMAIL,name:NAME,method:'email'});
  if (ok && data.mockOtp) { document.getElementById('mock-otp').textContent=data.mockOtp; document.getElementById('mock-box').style.display='flex'; }
}

document.getElementById('verify-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  document.getElementById('error-box').style.display='none';
  const code=document.getElementById('otp').value;
  const btn=document.getElementById('verify-btn'); btn.disabled=true; btn.innerHTML='<span class="spinner"></span> Verifying...';
  const {ok,data} = await api('api/auth/verify-otp.php','POST',{email:EMAIL,code});
  btn.disabled=false; btn.textContent='Verify Email';
  if (!ok) { document.getElementById('error-box').textContent=data.error||'Verification failed'; document.getElementById('error-box').style.display='flex'; return; }
  document.getElementById('success-box').textContent='Email verified! Your account is pending admin approval. You will be able to login once approved.';
  document.getElementById('success-box').style.display='flex';
  document.getElementById('verify-form').style.display='none';
  setTimeout(() => window.location.href='login.php', 3000);
});
</script>
</body></html>
