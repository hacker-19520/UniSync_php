<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$requestId = (int)($_GET['id'] ?? 0);
$currentUserId = (int)$_SESSION['user_id'];
// Verify access
$stmt = $conn->prepare("SELECT * FROM requests WHERE id=? AND status='accepted' AND (senderId=? OR receiverId=?)");
$stmt->bind_param("iii",$requestId,$currentUserId,$currentUserId); $stmt->execute();
$req = $stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$req) { header('Location: matches.php'); exit; }
// Get match info
$matchUserId = ($req['senderId']==$currentUserId) ? $req['receiverId'] : $req['senderId'];
$stmt=$conn->prepare("SELECT id,name,university,image FROM users WHERE id=?"); $stmt->bind_param("i",$matchUserId); $stmt->execute();
$matchUser=$stmt->get_result()->fetch_assoc(); $stmt->close();
// Load initial messages
$stmt=$conn->prepare("SELECT m.id,m.senderId,m.content,m.createdAt,u.name as sendername,u.image as senderimage FROM messages m JOIN users u ON m.senderId=u.id WHERE m.requestId=? ORDER BY m.createdAt ASC");
$stmt->bind_param("i",$requestId); $stmt->execute();
$messages=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
$lastId = !empty($messages) ? end($messages)['id'] : 0;
$pageTitle = 'Chat - ' . ($matchUser['name'] ?? 'User');
$activePage = 'matches';
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title><?= htmlspecialchars($pageTitle) ?> - UniSync</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main-content animate-fade-in" style="padding:24px;display:flex;flex-direction:column;">

    <!-- Chat Header -->
    <div class="chat-header" style="margin-bottom:0;border-radius:12px 12px 0 0;">
      <a href="matches.php?tab=matches" style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:#f3f4f6;transition:background .2s;" onmouseover="this.style.background='#e5e7eb'" onmouseout="this.style.background='#f3f4f6'">
        <svg style="width:20px;height:20px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
      </a>
      <?php if ($matchUser): ?>
        <img src="<?= htmlspecialchars($matchUser['image'] ?? '') ?>" class="avatar-sm" style="border:2px solid #dbeafe;" onerror="this.src='https://via.placeholder.com/40'">
        <div>
          <p style="font-weight:700;"><?= htmlspecialchars($matchUser['name']) ?></p>
          <p style="font-size:.8rem;color:#6b7280;"><?= htmlspecialchars($matchUser['university'] ?? '') ?></p>
        </div>
      <?php endif; ?>
      <div style="margin-left:auto;display:flex;align-items:center;gap:6px;">
        <span id="online-dot" style="width:8px;height:8px;border-radius:50%;background:#16a34a;display:inline-block;"></span>
        <span style="font-size:.8rem;color:#6b7280;">Active</span>
      </div>
    </div>

    <!-- Messages Area -->
    <div id="chat-messages" class="chat-messages" style="flex:1;min-height:0;height:calc(100vh - 280px);">
      <?php foreach ($messages as $msg): ?>
        <?php
          $isMe = (int)$msg['senderId'] === $currentUserId;
          $time = date('h:i A', strtotime($msg['createdAt']));
        ?>
        <div class="msg <?= $isMe ? 'mine' : 'theirs' ?>" data-msg-id="<?= (int)$msg['id'] ?>">
          <?php if (!$isMe && $msg['senderimage']): ?>
            <img src="<?= htmlspecialchars($msg['senderimage']) ?>" class="msg-avatar" onerror="this.src='https://via.placeholder.com/32'">
          <?php endif; ?>
          <div>
            <?php if (!$isMe): ?>
              <p class="msg-name"><?= htmlspecialchars($msg['sendername']) ?></p>
            <?php endif; ?>
            <div class="msg-bubble">
              <?= htmlspecialchars($msg['content']) ?>
              <span class="msg-time"><?= $time ?></span>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($messages)): ?>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#9ca3af;text-align:center;padding:40px;">
          <svg style="width:52px;height:52px;opacity:.3;margin-bottom:12px;" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
          <p>No messages yet. Start the conversation!</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- Input Area -->
    <div class="chat-input-area" style="border-radius:0 0 12px 12px;">
      <input type="text" id="msg-input" class="input-field" placeholder="Type a message..." style="flex:1;" autocomplete="off">
<button id="send-btn" class="btn btn-primary" style="padding:10px 18px;">
        <svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      </button>
    </div>
  </main>
</div>
<script src="assets/app.js"></script>
<script>
const REQUEST_ID = <?= $requestId ?>;
const CURRENT_USER_ID = <?= $currentUserId ?>;
let lastId = <?= $lastId ?>;

const chatBox = document.getElementById('chat-messages');
chatBox.scrollTop = chatBox.scrollHeight;

const msgInput = document.getElementById('msg-input');
const sendBtn = document.getElementById('send-btn');
sendBtn.addEventListener('click', sendMessage);

// Enter key to send
msgInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

let sending = false;
let sendTimeout = null;

async function sendMessage() {
  if (sending) return;
  
  // Debounce rapid calls
  if (sendTimeout) clearTimeout(sendTimeout);
  sendTimeout = setTimeout(async () => {
    const input = msgInput;
    const btn = sendBtn;
    const content = input.value.trim();
    
    if (!content) return;
    
    sending = true;
    input.value = '';
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Sending...';
    
    try {
      const {ok, data} = await api('api/messages/send.php', 'POST', {requestId: REQUEST_ID, content});
      if (ok && data.data) {
        appendMessage(data.data);
      } else {
        input.value = content;
        showToast('Failed to send. Try again.', 'error');
      }
    } catch (e) {
      input.value = content;
      showToast('Network error. Try again.', 'error');
    } finally {
      sending = false;
      btn.disabled = false;
      btn.innerHTML = '<svg style="width:18px;height:18px;" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
      // Safety reset
      setTimeout(() => { sending = false; }, 5000);
    }
  }, 250);
}

function appendMessage(msg) {
  if (!msg || !msg.id) return;
  // Prevent duplicate rendering from polling overlap.
  if (chatBox.querySelector(`[data-msg-id="${msg.id}"]`)) return;

  const isMe = parseInt(msg.senderId) === CURRENT_USER_ID;
  const time = new Date(msg.createdAt).toLocaleTimeString('en-US', {hour12: false, hour: '2-digit', minute: '2-digit'});
  const avatarHtml = !isMe && msg.senderimage ? `<img src="${escHtml(msg.senderimage)}" class="msg-avatar" onerror="this.src='https://via.placeholder.com/32'">` : '';
  const nameHtml = !isMe ? `<p class="msg-name">${escHtml(msg.sendername||'User')}</p>` : '';
  const div = document.createElement('div');
  div.className = `msg ${isMe?'mine':'theirs'}`;
  div.setAttribute('data-msg-id', msg.id);
  div.innerHTML = `${avatarHtml}<div>${nameHtml}<div class="msg-bubble">${escHtml(msg.content)}<span class="msg-time">${time}</span></div></div>`;
  // Remove empty-state if present
  const empty = chatBox.querySelector('[style*="flex-direction:column"]');
  if (empty) empty.remove();
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
  if (msg.id > lastId) lastId = msg.id;
}

// Poll for new messages every 3 seconds (skip own messages to prevent duplicate)
if (typeof lastMessageId !== 'undefined') {
  lastMessageId = lastId;
}
startChatPolling(REQUEST_ID, CURRENT_USER_ID, (msgs) => {
  msgs.forEach(m => {
    if (parseInt(m.senderId) !== CURRENT_USER_ID) {
      appendMessage(m);
    }
  });
});

window.addEventListener('beforeunload', stopChatPolling);
</script>
</body>
</html>
