<?php
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function verifySession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(['error' => 'Unauthorized'], 401);
    }
}

function generateOTP($length = 6) {
    return strval(random_int(10 ** ($length - 1), (10 ** $length) - 1));
}

function sendOTPEmail($email, $otp) {
    $subject = "UniSync - Your Login OTP";
    $message = "Your OTP for login is: $otp\n\nThis OTP is valid for 10 minutes.";
    $headers = "From: noreply@unisync.com\r\n";
    return mail($email, $subject, $message, $headers);
}