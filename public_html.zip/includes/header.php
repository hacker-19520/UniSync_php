<?php
require_once __DIR__ . '/auth.php';
$currentUser = is_logged_in() ? get_session_user() : null;
$pageTitle = $pageTitle ?? 'UniSync';
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="UniSync - Find Your University Duo. Connect with students who share your qualities and ambitions.">
  <title><?= htmlspecialchars($pageTitle) ?> - UniSync</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
