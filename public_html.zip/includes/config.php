<?php
// Database configuration for Hostinger
// Replace these with your actual Hostinger database credentials
define('DB_HOST', 'localhost'); // Hostinger (usually localhost)
define('DB_USER', 'u638387449_UniSync'); // Your DB user
define('DB_PASS', 'Macnitosh@12'); // Your DB pass
define('DB_NAME', 'u638387449_UniSync'); // Your DB name

define('APP_NAME', 'UniSync');
define('APP_URL', 'https://unisync.online'); // Live domain
define('SESSION_NAME', 'unisync_session');

// OTP mode: 'mock' shows OTP on screen, 'email' sends real email
define('OTP_MODE', 'mock'); // Mock OTP for testing

// SMTP config for Hostinger (use your email provider's settings)
define('SMTP_HOST', 'smtp.hostinger.com'); // Hostinger SMTP host
define('SMTP_PORT', 587);
define('SMTP_USER', 'your_email@yourdomain.com'); // Your email
define('SMTP_PASS', 'your_email_password'); // Your email password or app password
define('SMTP_FROM', 'UniSync <noreply@yourdomain.com>');
?>
