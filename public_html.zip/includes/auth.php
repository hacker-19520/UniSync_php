<?php
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

function get_session_user() {
    return [
        'id'       => $_SESSION['user_id'] ?? null,
        'name'     => $_SESSION['user_name'] ?? null,
        'email'    => $_SESSION['user_email'] ?? null,
        'is_admin' => $_SESSION['is_admin'] ?? false,
    ];
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        header('Location: dashboard.php');
        exit;
    }
}

function set_session_user($user) {
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
$_SESSION['is_admin']   = (bool)($user['isAdmin'] ?? $user['isadmin'] ?? false);

}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function generate_otp() {
    return str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
}

function send_otp_email($email, $otp, $name, $type = 'verification') {
    if (OTP_MODE === 'mock') {
        // In mock mode, OTP is returned in the API response
        return true;
    }
    // Real email sending would go here (PHPMailer)
    return false;
}
