-- UniSync Exact Schema (Hostinger phpMyAdmin - Paste to SQL tab AFTER creating DB u638387449_UniSync)

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `rollNo` VARCHAR(100) UNIQUE,
  `sapId` VARCHAR(100) UNIQUE,
  `university` VARCHAR(255) NOT NULL,
  `department` VARCHAR(255) NOT NULL,
  `course` VARCHAR(255) NOT NULL,
  `shift` VARCHAR(50),
  `section` VARCHAR(10),
  `semester` VARCHAR(20),
  `image` TEXT NOT NULL,
  `reason` TEXT NOT NULL,
  `qualities` TEXT,
  `isVerified` TINYINT(1) DEFAULT 0,
  `isAdmin` TINYINT(1) DEFAULT 0,
  `approvalStatus` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `rejectionReason` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `otp_codes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL,
  `code` VARCHAR(6) NOT NULL,
  `expiresAt` DATETIME NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `senderId` INT NOT NULL,
  `receiverId` INT NOT NULL,
  `status` ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiverId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_request` (`senderId`, `receiverId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `requestId` INT NOT NULL,
  `senderId` INT NOT NULL,
  `content` TEXT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`requestId`) REFERENCES `requests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin 1 (password = 'password')
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `university`, `department`, `course`, `image`, `reason`, `isVerified`, `isAdmin`, `approvalStatus`) VALUES 
('Admin', 'admin@unisync.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emerson University', 'Software Engineering', 'BS SE', 'https://ui-avatars.com/api/?name=Admin&size=128&background=2563eb&color=fff', 'Admin', 1, 1, 'approved');

-- Admin 2 (ahmad - same hash)
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `university`, `department`, `course`, `image`, `reason`, `isVerified`, `isAdmin`, `approvalStatus`) VALUES 
('Ahmad Bilal', 'ahmadbilal9436@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emerson University', 'Software Engineering', 'BS SE', 'https://ui-avatars.com/api/?name=Ahmad+Bilal&size=128&background=2563eb&color=fff', 'Admin', 1, 1, 'approved');

-- Mock OTP for login
INSERT IGNORE INTO `otp_codes` (`email`, `code`, `expiresAt`) VALUES 
('admin@unisync.com', '123456', DATE_ADD(NOW(), INTERVAL 1 HOUR)),
('ahmadbilal9436@gmail.com', '123456', DATE_ADD(NOW(), INTERVAL 1 HOUR));

-- Password = 'password' for both admins

