<?php
require_once __DIR__ . '/../includes/config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$conn->query("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db(DB_NAME);

$queries = [
    // Users table
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        rollNo VARCHAR(100) UNIQUE,
        sapId VARCHAR(100) UNIQUE,
        university VARCHAR(255) NOT NULL,
        department VARCHAR(255) NOT NULL,
        course VARCHAR(255) NOT NULL,
        shift VARCHAR(50),
        section VARCHAR(10),
        semester VARCHAR(10),
        image LONGTEXT NOT NULL,
        reason VARCHAR(100) NOT NULL,
        qualities TEXT,
        isVerified TINYINT(1) DEFAULT 0,
        isAdmin TINYINT(1) DEFAULT 0,
        approvalStatus ENUM('pending','approved','rejected') DEFAULT 'pending',
        rejectionReason TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    // OTP codes table
    "CREATE TABLE IF NOT EXISTS otp_codes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        code VARCHAR(10) NOT NULL,
        expiresAt DATETIME NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    // Requests table
    "CREATE TABLE IF NOT EXISTS requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        senderId INT NOT NULL,
        receiverId INT NOT NULL,
        status ENUM('pending','accepted','rejected') DEFAULT 'pending',
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_request (senderId, receiverId),
        FOREIGN KEY (senderId) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (receiverId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    // Messages table
    "CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        requestId INT NOT NULL,
        senderId INT NOT NULL,
        content TEXT NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (requestId) REFERENCES requests(id) ON DELETE CASCADE,
        FOREIGN KEY (senderId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

$errors = [];
foreach ($queries as $sql) {
    if (!$conn->query($sql)) {
        $errors[] = $conn->error;
    }
}

if (empty($errors)) {
    echo '<div style="font-family:sans-serif;max-width:600px;margin:60px auto;padding:30px;background:#f0fdf4;border:2px solid #22c55e;border-radius:12px;">';
    echo '<h2 style="color:#15803d;">✅ Database Initialized Successfully!</h2>';
    echo '<p style="color:#166534;">All tables created in database <strong>' . DB_NAME . '</strong></p>';
    echo '<p>Tables created: <code>users</code>, <code>otp_codes</code>, <code>requests</code>, <code>messages</code></p>';
    echo '<a href="/" style="display:inline-block;margin-top:16px;background:#2563eb;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;">Go to UniSync →</a>';
    echo '</div>';
} else {
    echo '<div style="font-family:sans-serif;max-width:600px;margin:60px auto;padding:30px;background:#fef2f2;border:2px solid #ef4444;border-radius:12px;">';
    echo '<h2 style="color:#dc2626;">❌ Errors occurred:</h2>';
    foreach ($errors as $e) {
        echo '<p style="color:#7f1d1d;">' . htmlspecialchars($e) . '</p>';
    }
    echo '</div>';
}
$conn->close();
